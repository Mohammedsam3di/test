sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function (JSONModel) {
	"use strict";

	return JSONModel.extend("gmt_dev_plm_apps_ilbl.model.ApplicationModel", {

		constructor: function () {
			// create data
			var oData = {
				supplier: "",
				fromdate: "",
				todate: "",
				plant: "",
				pickD: "",
				aSysAlia: "",
				Action: "",
				selectedDateFrom: "",
				selectedDateTo: "",
				dToday:"",
				dPostToday:"",
				aTableData: [],
				aTableOriginalData: [],
				aCurrencyCollection:[],
				dCalPickUpDate: "",
				fromMainCtrl: false,
				fromPackCtrl: false,
				bNextPressEnable: false,
				saveSuccess: false,
				bWithoutSelect: false,
				bBackMessage: false,
				bTurkishPlant: false,
				bChange:false,
				bLoadData:true,
				bEditable:true,
				aSelectedTabData: [],
				oGoodsSupplier: [],
				oSelectedItem: {},
				oControllers: {
					"main": null,
					"create": null,
					"pack": null
				}
			};

			// call super constructor
			JSONModel.call(this, oData);
		}

	});

});