sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	'sap/m/MessageBox',
	"sap/ui/model/Filter",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	'sap/m/Dialog',
	"sap/ui/model/Sorter",
	'sap/m/Button',
	"bsh_tranship/model/formatter",
	"sap/ui/core/routing/History",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/m/BusyDialog",
	"bsh_tranship/model/constants",
	"bsh_tranship/controller/BaseController",
	"bsh_tranship/utils/ValidationException"
], function (Controller, JSONModel, ODataModel, MessageBox, Filter, Export,
	ExportTypeCSV, Dialog, Sorter, Button, formatter, History, FilterOperator, MessageToast, BusyDialog, Const, BaseController,
	ValidationException) {
	"use strict";
	var bundle, _self, respName = [],
		gSupplier;
	var gSupplier, gFromD, gToDat, gPlant, gpickD;
	return BaseController.extend("bsh_tranship.controller.pack", {
		formatter: formatter,
		onInit: function () {
			this._oMainController = this.getMainController();
			// this._oMainController.setControllerObject(this, "pack");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this),
				oView = this.getView();
			oRouter.getRoute("pack").attachPatternMatched(this._onObjectMatched, this);
			this.bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			this.getView().byId("validateStep2").setVisible(true);
			this.oModel = new ODataModel("/sap/opu/odata/BSHP/PO_TRANSPORT_SRV;mo/", {
				useBatch: false
			});
			/*this.oPackModel = new JSONModel();
			this.oPackModel1 = new JSONModel();
			oView.setModel(this.oPackModel, "oPackModel");
			oView.setModel(this.oPackModel1, "oPackModel1");*/
			// this._setInitialData();
		},
		onAfterRendering: function () {
			/*var oView = this.getView();
			this.oPackModel = new JSONModel();
			this.oPackModel1 = new JSONModel();
			oView.setModel(this.oPackModel, "oPackModel");
			oView.setModel(this.oPackModel1, "oPackModel1");
			this._setInitialData();*/
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			appModel.getData().oControllers['pack'] = this;
			appModel.setProperty("/bundle", this.bundle);
			var minValChecker = function (oEvent, appModel) {
				var aPalletInfo = this.getParent().getModel("oPackModel").getProperty("/aPalletInfo"),
					aPallets = this.getParent().getModel("oPackModel1").getProperty("/aPalletInfo"),
					bundle = this.getParent().getModel("appModel").getProperty("/bundle"),
					/*height = bundle.getText("height"),
					width = bundle.getText("width"),
					length = bundle.getText("length"),*/
					height = "Height",
					width = "Width",
					length = "length",
					val = this.getValue();
				val = val.toString();
				val = val.replace(/[^0-9\.]+/g, '');
				val = parseInt(val, 10);
				if (val.toString() == "NaN") {
					val = "";
				}
				this.setValue(val);

				var valC = this.getValue();

				var idC = oEvent.currentTarget.id.split('-')
				idC = idC[6];
				var flag = true;

				for (var p = 0; p < aPalletInfo.length; p++) {

					if (aPallets[idC].PackagingType ==
						aPalletInfo[p].PackagingType) {

						if (this.getPlaceholder() == height) {
							if (parseFloat(aPalletInfo[p].HeightMin) > parseFloat(valC)) {

								MessageBox.error(
									bundle.getText("heightShouldBeMoreThanX") + " " + parseFloat(aPalletInfo[p].HeightMin) + " " + bundle.getText("extra"), {
										title: bundle.getText("error"),
										actions: bundle.getText("close")
									});

								valC = "";
								this.setValue(valC);
							}
						} else if (this.getPlaceholder() == width) {
							if (parseFloat(aPalletInfo[p].WidthMin) > parseFloat(valC)) {

								MessageBox.error(
									bundle.getText("widthShouldBeMoreThanX") + " " + parseFloat(aPalletInfo[p].WidthMin) + " " + bundle.getText("extra"), {
										title: bundle.getText("error"),
										actions: bundle.getText("close")
									});

								valC = "";
								this.setValue(valC);
							}
						} else if (this.getPlaceholder() == length) {
							if (parseFloat(aPalletInfo[p].LengthMin) > parseFloat(valC)) {
								// var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;

								MessageBox.error(
									bundle.getText("lengthShouldBeMoreThanX") + " " + parseFloat(aPalletInfo[p].LengthMin) + " " + bundle.getText("extra"), {
										title: bundle.getText("error"),
										actions: bundle.getText("close")
									});

								valC = "";
								this.setValue(valC);
							}
						}
					}
				}
			};
			this.byId("lengthId").attachBrowserEvent("focusout", minValChecker);
			this.byId("weightId").attachBrowserEvent("focusout", minValChecker);
			this.byId("heightId").attachBrowserEvent("focusout", minValChecker);
		},
		_setInitialData: function () {
			var oView = this.getView(),
				appModel = this.getOwnerComponent().getModel("appModel"),
				oPackModel = oView.getModel("oPackModel");
			oView.byId("idTruckType").setSelectedKey("");
			oView.byId("idUnloadingPoint").setSelectedKey("");
			appModel.setProperty("/aPalletInfo", []);
			appModel.setProperty("/aNavPalletDeletedInfo", []);
			appModel.setProperty("/aTransportDateTimeInfo", []);
			appModel.setProperty("/bSubmitBtnEnabled", false);
			appModel.setProperty("/bNavPalletDeleted", false);
			oPackModel.setProperty("/LoadNo", "");
			oPackModel.setProperty("/aGoodSupplierInfo", []);
			oPackModel.setProperty("/aPalletInfo", []);
			oPackModel.setProperty("/aPackagingInfo", []);
			oPackModel.setProperty("/aTransportDateTimeInfo", []);
			oPackModel.setProperty("/aUnloadPointSetInfo", []);
			oPackModel.setProperty("/aTruckTypeF4SetInfo", []);
			oPackModel.setProperty("/aTransNotifSetInfo", [])
			oPackModel.setProperty("/aAvisDetailSetInfo", []);
			this.oPackModel1.setProperty("/aPalletInfo", []);
			appModel.refresh(true);
			oPackModel.refresh(true);
			this.oPackModel1.refresh(true);
		},
		_onObjectMatched: function (oEvent) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			if (appModel.getProperty("/bLoadData")) {
				this._getPlantTransport();
				appModel.setProperty("/bLoadData", false);
			}
			// if(appModel.getProperty("/Action") == "CH" && )

		},
		_getPlantTransport: function () {
			var oView = this.getView();
			this.oPackModel = new JSONModel();
			this.oPackModel1 = new JSONModel();
			oView.setModel(this.oPackModel, "oPackModel");
			oView.setModel(this.oPackModel1, "oPackModel1");
			this._setInitialData();
			var aFilter = [],
				// oView = this.getView(),
				appModel = oView.getModel("appModel");
			var sSupplier = oView.getModel("appModel").getProperty("/supplier");
			aFilter.push(new Filter("SAP__Origin", FilterOperator.EQ, appModel.getProperty("/oSelectedItem").SAP__Origin));
			aFilter.push(new Filter("Vendor", FilterOperator.EQ, btoa(sSupplier)));
			aFilter.push(new Filter("Plant", FilterOperator.EQ, oView.getModel("appModel").getProperty("/oSelectedItem").Plant));
			this.openBusyDialog();
			this.oModel.read("/PlantTransportSet", {
				filters: aFilter,
				success: function (data) {
					this.closeBusyDiaog();
					var oData = data.results;
					oView.getModel("oPackModel").setProperty("/aPackagingInfo", data.results);
					oView.byId("idPlantTransport").setModel("oPackModel");
					oView.getModel("appModel").getProperty("/Action") == "CH" ? oView.byId("idPlantTransport").setEditable(false) : oView.byId(
						"idPlantTransport").setEditable(true);
					// oView.getModel("appModel").getProperty("/Action") == "CH" ? this._getDeleteBtnVisibility() : oView.byId("idDeleteButton").setVisible(
					// 	false); //Change it to a common function of above two lines
					if (oData.length == 1) {
						oView.byId("idPlantTransport").setSelectedKey(oData[0].PlantTrans);
						this.onPlantSupplierChange("M");
					} else if (oView.getModel("appModel").getProperty("/Action") == "CH") {
						this.getPackaginData();
						// oView.byId("idPlantTransport").setEditable(false);
					} else {
						oView.byId("idPlantTransport").setSelectedKey("");
					}
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show(this.bundle.getText("error") + ":" + msg);
				}.bind(this)
			});
		},
		onPlantSupplierChange: function (oEvent) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			var oSelectedPlantSupp = jQuery.grep(oView.getModel("oPackModel").getProperty("/aPackagingInfo"), function (oObj) {
				return oObj.PlantTrans == oView.byId("idPlantTransport").getSelectedKey();
			});
			appModel.setProperty("/oSelectedPlantSupp", oSelectedPlantSupp[0]);
			this.getPackaginData();
		},

		_getDeleteBtnVisibility: function () {
			var aFilter = [],
				oView = this.getView(),
				appModel = oView.getModel("appModel");
			var sSupplier = oView.getModel("appModel").getProperty("/supplier");
			// aFilter.push(new Filter("Date", FilterOperator.BT, appModel.getProperty("/selectedDateFrom"), appModel.getProperty("/selectedDateTo")));
			aFilter.push(new Filter("Date", FilterOperator.BT, appModel.getProperty("/fromdate"), appModel.getProperty("/todate")));
			aFilter.push(new Filter("Vendor", FilterOperator.EQ, btoa(sSupplier)));
			aFilter.push(new Filter("Plant", FilterOperator.EQ, appModel.getProperty("/oSelectedItem").Plant));
			aFilter.push(new Filter("Loadingnumber", FilterOperator.EQ, appModel.getProperty("/LoadingNo")));
			this.oModel.read("/TransportMainSet", {
				filters: aFilter,
				success: function (data) {
					if (data.results.length > 0 && parseFloat(data.results[0].ShipmentCost) == 0)
						this.getView().byId("idDeleteButton").setVisible(true);
				}.bind(this),
				error: function (msg) {

				}.bind(this)
			});
		},

		getPackaginData: function () {
			var aPromise = [];
			aPromise.push(this.getTransNotifSet());
			Promise.all(aPromise).then(function () {
				this.getPalletValidSet();
				this.getTransportDateTimeSet();
				this.getUnloadPointSet();
				this.getTruckTypeF4Set();
			}.bind(this));
			// this.getAvisDetailSet();
			this._checkSubmitBtnVisibility();
		},
		getGoodSupplierF4Set: function () {
			var aFilter = this.getFilter("GoodSupplier"),
				oView = this.getView(),
				appModel = oView.getModel("appModel");
			this.openBusyDialog();
			this.oModel.read("/GoodSupplierF4Set", {
				filters: aFilter,
				success: function (data) {
					this.closeBusyDiaog();
					var oData = data;
					oView.getModel("oPackModel").setProperty("/aGoodSupplierInfo", data.results[0]);
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show(this.bundle.getText("error") + ":" + msg);
				}.bind(this)
			});
		},
		getPalletValidSet: function () {
			var aFilter = this.getFilter("PalletValid"),
				oView = this.getView(),
				appModel = oView.getModel("appModel");
			this.openBusyDialog();
			// return new Promise(function (resolve, reject) {
			this.oModel.read("/PalletValidSet", {
				filters: aFilter,
				success: function (data) {
					this.closeBusyDiaog();
					var oData = data;
					oView.getModel("oPackModel").setProperty("/aPalletInfo", data.results);
					this._checkSubmitBtnVisibility();
					// resolve();
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show(this.bundle.getText("error") + ":" + msg);
					// reject();
				}.bind(this)
			});
			// }.bind(this));

		},
		getTransportDateTimeSet: function () {
			var aFilter = this.getFilter("TransportDateTime"),
				oView = this.getView(),
				appModel = oView.getModel("appModel");
			this.openBusyDialog();
			// return new Promise(function (resolve, reject) {
			this.oModel.read("/TransportDateTimeSet" + aFilter, {
				// filters: aFilter,
				success: function (data) {
					this.closeBusyDiaog();
					var oData = data;
					oView.getModel("oPackModel").setProperty("/aTransportDateTimeInfo", [data]);
					// oView.byId("idUnloadingPoint").setSelectedKey(data.UnloadingPoint);
					if (data.ArrivalDate == "" && appModel.getProperty("/bEditable")) {
						oView.byId("idArrDate").setEditable(true);
						// oView.byId("idArrDate").setValue(data[0].ArrivalDate);
					} else {
						oView.byId("idArrDate").setEditable(false);
						oView.byId("idArrDate").setValue(data.ArrivalDate)
					}
					this._checkSubmitBtnVisibility();
					// resolve();
					// oView.getModel("oPackModel").refresh(true);
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show(this.bundle.getText("error") + ":" + msg);
					// reject();
				}.bind(this)
			});

			// }.bind(this));

		},
		getUnloadPointSet: function () {
			var aFilter = this.getFilter("UnloadingPoint"),
				oView = this.getView(),
				appModel = oView.getModel("appModel"),
				oPackModel = oView.getModel("oPackModel");
			this.openBusyDialog();
			// return new Promise(function (resolve, reject) {
			this.oModel.read("/UnloadPointSet", {
				filters: aFilter,
				success: function (data) {
					this.closeBusyDiaog();
					var oData = data.results;
					oView.getModel("oPackModel").setProperty("/aUnloadPointSetInfo", data.results);
					if (oView.getModel("appModel").getProperty("/Action") == "CH") {
						oView.byId("idUnloadingPoint").setSelectedKey(oPackModel.getProperty("/oNavHeader").UnloadingPoint);
					} else if (oData.length == 1) {
						oView.byId("idUnloadingPoint").setSelectedKey(oPackModel.getProperty("/aUnloadPointSetInfo/0/UnloadingPoint"));
					} else {
						oView.byId("idUnloadingPoint").setSelectedKey("");
					}
					this._checkSubmitBtnVisibility();
					// resolve();
					// oView.getModel("oPackModel").refresh();
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show(this.bundle.getText("error") + ":" + msg);
					// reject();
				}.bind(this)
			});
			// }.bind(this));

		},
		getTruckTypeF4Set: function () {
			var aFilter = this.getFilter("TruckTypeF4"),
				oView = this.getView(),
				appModel = oView.getModel("appModel"),
				oPackModel = oView.getModel("oPackModel");
			this.openBusyDialog();
			// return new Promise(function (resolve, reject) {
			this.oModel.read("/TruckTypeF4Set", {
				filters: aFilter,
				success: function (data) {
					this.closeBusyDiaog();
					var oData = data.results;
					oView.getModel("oPackModel").setProperty("/aTruckTypeF4SetInfo", data.results);
					if (oView.getModel("appModel").getProperty("/Action") == "CH") {
						this.getView().byId("idTruckType").setSelectedKey(oPackModel.getProperty("/oNavHeader").TruckType);
					} else if (oData.length == 1) {
						oView.byId("idTruckType").setSelectedKey(oData[0].Vhilm);
					} else {
						oView.byId("idTruckType").setSelectedKey("");
					}
					this._checkSubmitBtnVisibility();
					// resolve();
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show(this.bundle.getText("error") + ":" + msg);
					// reject();
				}.bind(this)
			});
			// }.bind(this));

		},
		getAvisDetailSet: function () {
			var aFilter = this.getFilter("AvisDetail"),
				oView = this.getView(),
				appModel = oView.getModel("appModel");
			this.openBusyDialog();
			this.oModel.read("/AvisDetailSet", {
				filters: aFilter,
				success: function (data) {
					this.closeBusyDiaog();
					var oData = data;
					oView.getModel("oPackModel").setProperty("/aAvisDetailSetInfo", data.results);
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show(this.bundle.getText("error") + ":" + msg);
				}.bind(this)
			});
		},
		getTransNotifSet: function () {
			var aFilter = this.getFilter("TransNotif"),
				oView = this.getView(),
				oNavHeader = [],
				oNavItems = [],
				appModel = oView.getModel("appModel"),
				oPackModel = oView.getModel("oPackModel");
			oView.getModel("oPackModel").setProperty("/oNavHeader", oNavHeader);
			this.openBusyDialog();
			return new Promise(function (resolve, reject) {
				this.oModel.read("/TransNotifSet", {
					urlParameters: {
						"$expand": "NavHead,NavItem",
						"$format": "json",
						"xyz": Math.random()
					},
					filters: aFilter,
					success: function (data, header) {
						this.closeBusyDiaog();
						oView.getModel("oPackModel").setProperty("/aTransNotifSetInfo", data.results);
						appModel.setProperty("/myetag", header.headers.myetag);

						if (data.results[0].NavHead.results.length > 0) {
							oNavHeader = data.results[0].NavHead.results[0];
							oView.getModel("oPackModel").setProperty("/oNavHeader", oNavHeader);
							oView.byId("idGoodsSupplier").setValue(oNavHeader.GoodsSupplier + " - " + oNavHeader.GoodsSupplierDesc);
							oView.byId("idUnloadingPoint").setValue(oNavHeader.UnloadingPoint + " - " + oNavHeader.UnloadingDescr);
							if (oView.getModel("appModel").getProperty("/Action") == "CH" && oView.byId("idPlantTransport").getSelectedKey() == "") {
								oView.byId("idPlantTransport").setSelectedKey(oNavHeader.PlantTransport);
								var oSelectedPlantSupp = jQuery.grep(oView.getModel("oPackModel").getProperty("/aPackagingInfo"), function (oObj) {
									return oObj.PlantTrans == oView.byId("idPlantTransport").getSelectedKey();
								});
								appModel.setProperty("/oSelectedPlantSupp", oSelectedPlantSupp[0]);
							}
							oView.byId("idTruckType").setValue(oNavHeader.TruckType + " - " + oNavHeader.TruckTypDescr);
							oNavHeader.Weight = this.formatter.formatQuantity(oNavHeader.Weight);
							oNavHeader.TotalVolume = this.formatter.formatQuantity(oNavHeader.TotalVolume);
						}
						if (data.results[0].NavItem.results) {
							oNavItems = data.results[0].NavItem.results;
							oNavItems = jQuery.grep(oNavItems, function (oObj) {
								oObj.bCreated = true;
								oObj.bEnabled = true;
								return oObj;
							});
							oView.getModel("oPackModel1").setProperty("/aPalletInfo", oNavItems);
						}
						// oView.getModel("oPackModel").refresh();
						this._checkSubmitBtnVisibility();
						resolve();
						// this.getView().byId("idTruckType").setSelectedKey(data.results[0].Route);
					}.bind(this),
					error: function (msg) {
						this.closeBusyDiaog();
						MessageToast.show(this.bundle.getText("error") + ":" + msg);
						reject();
					}.bind(this)
				});
			}.bind(this));

		},
		getFilter: function (sSet) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				aFilter = [],
				sFilter = "";
			switch (sSet) {
			case 'GoodSupplier':
				aFilter.push(new Filter({
					path: "SAP__Origin",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").SAP__Origin
				}));
				aFilter.push(new Filter({
					path: "Plant",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").Plant
				}));
				aFilter.push(new Filter({
					path: "Vendor",
					operator: FilterOperator.EQ,
					value1: btoa(appModel.getProperty("/supplier"))
				}));
				aFilter.push(new Filter({
					path: "ShippingMethod",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedPlantSupp").ShipingMethod
				}));
				return aFilter;
				// break;
			case 'PalletValid':
				aFilter.push(new Filter({
					path: "SAP__Origin",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").SAP__Origin
				}));
				aFilter.push(new Filter({
					path: "Plant",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").Plant
				}));
				aFilter.push(new Filter({
					path: "Supplier",
					operator: FilterOperator.EQ,
					value1: btoa(appModel.getProperty("/supplier"))
				}));
				return aFilter;
				// break;
			case 'UnloadingPoint':
				aFilter.push(new Filter({
					path: "SAP__Origin",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").SAP__Origin
				}));
				aFilter.push(new Filter({
					path: "Plant",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").Plant
				}));
				aFilter.push(new Filter({
					path: "Vendor",
					operator: FilterOperator.EQ,
					value1: btoa(appModel.getProperty("/supplier"))
				}));
				aFilter.push(new Filter({
					path: "ShpMethod",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedPlantSupp").ShipingMethod
				}));
				aFilter.push(new Filter({
					path: "Route",
					operator: FilterOperator.EQ,
					// value1: "D63FLI" //#MS to do
					value1: oView.getModel("oPackModel").getProperty("/aPackagingInfo/0/Route")
				}));
				aFilter.push(new Filter({
					path: "GoodsSupplier",
					operator: FilterOperator.EQ,
					value1: btoa(appModel.getProperty("/oSelectedItem").GSvalue.split("-")[0]).trim()
				}));
				return aFilter;
			case 'TransportDateTime':
				sFilter = "(SAP__Origin='" + appModel.getProperty("/oSelectedItem").SAP__Origin + "',Vendor='" + btoa(appModel.getProperty(
						"/supplier")) +
					"',Plant='" + appModel.getProperty("/oSelectedItem").Plant +
					"',PickUpDate='" + appModel.getProperty("/aSelectedTabData/0/dispPickDate") + "',ArrivalDate='',ShippingMethod='" + appModel.getProperty(
						"/oSelectedPlantSupp").ShipingMethod +
					"',Route='" + oView.getModel("oPackModel").getProperty("/aPackagingInfo/0/Route") + "',LoadingNo='',GoodSupplier='" + btoa(
						appModel.getProperty("/oSelectedItem").GSvalue.split("-")[0]).trim() +
					"',SupplierUserId='" + btoa(this.getView().getModel("UserModel").getProperty("/user")) + "',CreateInd='X')";
				// sFilter= "(SAP__Origin='SUPPL_EMEA_FACT1',Vendor='Nzk=',Plant='5321',PickUpDate='',ArrivalDate='',ShippingMethod='ST',Route='D59DVO',LoadingNo='',GoodSupplier='',SupplierUserId='QTAwMjAzNzQz',CreateInd='X')";
				// aFilter.push(new Filter({
				// 	path: "SAP__Origin",
				// 	operator: FilterOperator.EQ,
				// 	value1: appModel.getProperty("/oSelectedItem").SAP__Origin
				// }));
				// aFilter.push(new Filter({
				// 	path: "Plant",
				// 	operator: FilterOperator.EQ,
				// 	value1: appModel.getProperty("/oSelectedItem").Plant
				// }));
				// aFilter.push(new Filter({
				// 	path: "Vendor",
				// 	operator: FilterOperator.EQ,
				// 	value1: appModel.getProperty("/oSelectedItem").Supplier
				// }));
				// aFilter.push(new Filter({
				// 	path: "ShippingMethod",
				// 	operator: FilterOperator.EQ,
				// 	value1: appModel.getProperty("/oSelectedPlantSupp").ShipingMethod
				// }));
				// aFilter.push(new Filter({
				// 	path: "Route",
				// 	operator: FilterOperator.EQ,
				// 	value1: ""
				// }));
				// aFilter.push(new Filter({
				// 	path: "GoodsSupplier",
				// 	operator: FilterOperator.EQ,
				// 	value1: ""
				// }));
				return sFilter;
			case 'TruckTypeF4':
				aFilter.push(new Filter({
					path: "SAP__Origin",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").SAP__Origin
				}));
				aFilter.push(new Filter({
					path: "Plant",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").Plant
				}));
				aFilter.push(new Filter({
					path: "Supplier",
					operator: FilterOperator.EQ,
					value1: btoa(appModel.getProperty("/supplier"))
						// value1: "Nzk="
				}));
				aFilter.push(new Filter({
					path: "Traab",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedPlantSupp").ShipingMethod
						// value1: "ST"
				}));
				return aFilter;
			case 'AvisDetail':
				sFilter = "SAP__Origin eq '" + appModel.getProperty("/oSelectedItem").SAP__Origin + "' and (Supplier eq '" + btoa(appModel.getProperty(
						"/supplier")) + "') and (Plant eq '" + appModel.getProperty("/oSelectedItem").Plant +
					"') and (LoadingNo eq '') and (GoodSupplier eq '" + btoa(appModel.getProperty("/oSelectedItem").Supplier) +
					"') and (ShippingMethod eq '" + appModel.getProperty("/oSelectedPlantSupp").ShipingMethod + "')&abc=" + Math.random();
				aFilter.push(new Filter({
					path: "SAP__Origin",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").SAP__Origin
				}));
				aFilter.push(new Filter({
					path: "Plant",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedItem").Plant
				}));
				aFilter.push(new Filter({
					path: "Supplier",
					operator: FilterOperator.EQ,
					value1: btoa(appModel.getProperty("/supplier"))
				}));
				aFilter.push(new Filter({
					path: "ShippingMethod",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/oSelectedPlantSupp").ShipingMethod
				}));
				aFilter.push(new Filter({
					path: "LoadingNo",
					operator: FilterOperator.EQ,
					value1: ""
				}));
				aFilter.push(new Filter({
					path: "GoodSupplier",
					operator: FilterOperator.EQ,
					value1: ""
				}));
				return aFilter;
			case 'TransNotif':
				aFilter.push(new Filter({
					path: "Vendor",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/supplier")
				}));
				aFilter.push(new Filter({
					path: "PickupDate",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/aSelectedTabData/0/dispPickDate")
				}));
				aFilter.push(new Filter({
					path: "Loading",
					operator: FilterOperator.EQ,
					value1: appModel.getProperty("/LoadingNo")
				}));
				return aFilter;
			default:
				break;
			}

		},
		resolveMultiFilter: function (oMultiFilter) {},
		createFilterSegment: function (sPath, sOperator, oValue1, oValue2, sFilterParam) {},
		getDetail: function (suppl, fromdate, todate, plant) {},
		setHeaderText: function (relNo, purdoc, reltype, MatNo) {
			var oUserData = this.getView().getModel('UserModel').getData();
			var title = this.bundle.getText("filter") + ": ";
			if (relNo) {
				title = title + this.bundle.getText("RelNo") + ": " + relNo + ", ";
			}
			if (purdoc) {
				title = title + this.bundle.getText("purdoc") + ": " + purdoc + ", ";
			}
			if (reltype) {
				title = title + this.bundle.getText("Releasetype") + ": " + reltype + ", ";
			}
			if (MatNo) {
				title = title + this.bundle.getText("Material") + ": " + MatNo;
			}
			this.getView().byId("idsnapedCnt").setTitle(title);
		},
		onPalletTypeChange: function (oEvent) {

		},
		onPalletReset: function (sId) {
			sap.ui.getCore().byId(sId).setSelectedKey("");
			sap.ui.getCore().byId(sId).setValue("");
		},
		validateStepPallet: function (oEvent) {
			var sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.oPackModel1.getPath(),
				oTablModel = this.getView().getModel("oPackModel1");
			if (oEvent.getParameter("selectedItem")) {
				var sValue = oEvent.getParameter("selectedItem").getKey(),
					aPalletInfo1 = this.getView().getModel("oPackModel1").getProperty("/aPalletInfo");

				/*var oDuplicateRowCheck = oRes = jQuery.grep(aPalletInfo1, function (oObj) {
						return oObj.PackagingType == sValue;
					});
				if (oDuplicateRowCheck.length >= 1) {
					this.resetTableEntry(oTablModel, sPath);
					var sId = oEvent.getParameter("id"),
						sMsg = sValue + " " + this.bundle.getText("palletalreadyexist");
					MessageBox.error(sMsg, {
						title: this.bundle.getText("error"),
						actions: this.bundle.getText("close"),
						onClose: function () {
							this.onPalletReset(sId);
						}.bind(this, sId),
						styleClass: this.bCompact ? "sapUiSizeCompact" : ""
					});

					return;
				}*/

				var aPalletInfo = this.getView().getModel("oPackModel").getProperty("/aPalletInfo"),
					oRes = jQuery.grep(aPalletInfo, function (oObj) {
						return oObj.PackagingType == sValue;
					});
				if (oRes.length == 1) {
					oRes = oRes[0];
					oTablModel.setProperty(sPath + "/PackagingType", oRes.PackagingType);
					oTablModel.setProperty(sPath + "/Length", oRes.Length);
					oTablModel.setProperty(sPath + "/Width", oRes.Width);
					oTablModel.setProperty(sPath + "/Height", oRes.Height);
					oTablModel.setProperty(sPath + "/bEnabled", true);
					oTablModel.refresh(true);
					this.totalVolumeCalculation();
				}
			} else {
				this.resetTableEntry(oTablModel, sPath);
			}

		},
		resetTableEntry: function (oTablModel, sPath) {
			oTablModel.setProperty(sPath + "/PackagingType", "");
			oTablModel.setProperty(sPath + "/Quantity", "");
			oTablModel.setProperty(sPath + "/Length", "");
			oTablModel.setProperty(sPath + "/Width", "");
			oTablModel.setProperty(sPath + "/Height", "");
			oTablModel.setProperty(sPath + "/Stackability", "");
			oTablModel.setProperty(sPath + "/bEnabled", false);
		},
		_onTimeChange: function (oEvent, sType) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				getTimeFrom = oView.byId("idPickupTimeFrom").getValue(),
				getTimeTo = oView.byId("idPickupTimeTo").getValue(),
				rRegexTime = /^([0-1][0-9]|2[0-3]):[0-5][0-9]$/,
				sTimeFrom = oView.byId("idPickupTimeFrom")._getInputValue(),
				sTimeTo = oView.byId("idPickupTimeTo")._getInputValue(),
				bundle = oView.getModel("i18n").getResourceBundle();
			appModel.setProperty("/bBackMessage", true);
			if (sType == "TF") {
				oView.byId("idPickupTimeTo").setValue("");
			} else {
				if (getTimeFrom != "" && getTimeFrom != "0000" && !rRegexTime.test(sTimeFrom)) {
					oView.byId("idPickupTimeFrom").setValueState(sap.ui.core.ValueState.Error);
					MessageBox.error(
						bundle.getText("TimeFromError"), {
							title: bundle.getText("error"),
							actions: bundle.getText("close"),
							styleClass: this.bCompact ? "sapUiSizeCompact" : ""
						});
					this._checkSubmitBtnVisibility();
					return;
				} else if ((getTimeTo != "" && getTimeTo != "0000" && !rRegexTime.test(sTimeTo))) {
					oView.byId("idPickupTimeTo").setValueState(sap.ui.core.ValueState.Error);
					MessageBox.error(
						bundle.getText("TimeToError"), {
							title: bundle.getText("error"),
							actions: bundle.getText("close"),
							styleClass: this.bCompact ? "sapUiSizeCompact" : ""
						});
					this._checkSubmitBtnVisibility();
					return;
				} else if ((getTimeFrom != "" && getTimeFrom != "0000") && (getTimeTo != "000000" && getTimeTo != "0000" && getTimeTo != "") &&
					getTimeFrom >= getTimeTo) {
					oView.byId("idPickupTimeFrom").setValueState(sap.ui.core.ValueState.Error);
					oView.byId("idPickupTimeTo").setValueState(sap.ui.core.ValueState.Error);
					var bCompact = !!oView.$().closest(".sapUiSizeCompact").length;
					// var bundle = oView.getModel("i18n").getResourceBundle();
					MessageBox.error(
						bundle.getText("lowerLimitIsGreaterThanUpperLimit"), {
							title: bundle.getText("error"),
							actions: bundle.getText("close"),
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						});
					oView.byId("idPickupTimeTo").setValue("");
					this._checkSubmitBtnVisibility();
					return;
				} else {
					oView.byId("idPickupTimeFrom").setValueState(sap.ui.core.ValueState.None);
					oView.byId("idPickupTimeTo").setValueState(sap.ui.core.ValueState.None);
				}
			}

			this._checkSubmitBtnVisibility();
		},
		onSortDetail: function () {},
		handleSorting: function (oEvent) {},
		onDownloadExcel: function () {},
		_onPressCancel: function () {
			var bundle = this.getView().getModel("i18n").getResourceBundle(),
				appModel = this.getView().getModel("appModel"),
				oDialog = new Dialog({
					title: bundle.getText("confirm"),
					type: 'Message',
					content: [
						new sap.m.Label({
							text: bundle.getText("wanttoleave")
						})
					],
					beginButton: new Button({
						text: bundle.getText("ok"),
						press: function () {
							oDialog.close();
							this._setInitialData();
							appModel.setProperty("/fromMainCtrl", false);
							appModel.setProperty("/fromPackCtrl", false);
							appModel.setProperty("/bNextPressEnable", false);
							appModel.setProperty("/bWithoutSelect", false);
							appModel.setProperty("/bBackMessage", false);
							var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
							oRouter.navTo("main");
						}.bind(this)
					}),
					endButton: new Button({
						text: bundle.getText("cancel"),
						press: function () {
							oDialog.close();
						}
					}),
					afterClose: function () {
						oDialog.destroy();
					}
				});
			oDialog.open();
		},
		onSubmitPress: function () {},
		pressBack: function () {
			//var oRouter = sap.ui.core.UIComponent.getRouterFor(_self);
			//oRouter.navTo("create",{suppl : btoa(gSupplier), fromdate: gFromD, todate: gToDat, plant: gPlant});
			var appModel = this.getView().getModel("appModel");
			appModel.setProperty("/fromMainCtrl", false);
			appModel.setProperty("/fromPackCtrl", true);
			history.go(-1);
		},
		_onpressAddRow: function (oEvent) {
			var jsonObj = {
				EupaMax: "",
				GridMax: " ",
				GridValid: "",
				Height: "",
				HeightMin: "",
				HoeheMax: "",
				Length: "",
				LengthMax: "",
				LengthMin: "",
				OthersMax: " ",
				OverMax: "0 ",
				PackagingType: "",
				PitchesMax: " ",
				Plant: "",
				SAP__Origin: "",
				Stackability: "",
				Supplier: "",
				VolMax: " ",
				WeightMax: " ",
				Width: "",
				WidthMax: "",
				WidthMin: "",
				wpaMax: "",
				bCreated: false,
				bEnabled: false
			}
			this.getView().getModel("oPackModel1").getProperty("/aPalletInfo").push(jsonObj);
			this.getView().getModel("oPackModel1").refresh(true);
			this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			this.totalVolumeCalculation();
		},
		_onpressDeleteRow: function (oEvent) {
			var oView = this.getView(),
				oModel = oView.getModel("oPackModel1"),
				appModel = oView.getModel("appModel"),
				oTable = oView.byId("idPalletTable"),
				aSelectedItems = oTable.getSelectedItems(),
				aPalletInfo = oModel.getProperty("/aPalletInfo"),
				sPath, oPalletInfo = "",
				bundle = this.getView().getModel("i18n").getResourceBundle(),
				i = 0;
			if (aSelectedItems.length == 0) {
				var sMsg = bundle.getText("selectOneRecord");
				MessageToast.show(sMsg);
			} else {
				for (i = aPalletInfo.length - 1; i >= 0; i--) {
					if (oTable.getItems()[i].getProperty("selected") === true) {
						aPalletInfo.splice(i, 1);
					}
				}
				oTable.removeSelections(true);
				oModel.refresh(true);
				this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			}
			this.totalVolumeCalculation();
		},
		blockChars: function (oEvent, sString) {
			var _oInput = oEvent.getSource(),
				sVal = _oInput.getValue(),
				bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length,
				aPalletInfo = this.getView().getModel("oPackModel").getProperty("/aPalletInfo"),
				oPalletInfo = aPalletInfo[0];
			sVal = sVal.toString();
			if (sVal.match(/[^0-9?,.]+/g)) {
				sVal = sVal.replace(/[^0-9?,.]+/g, '');
				_oInput.setValue(sVal);
			}
			//if(val != ""){ Defect-2471
			// this.validateStep2("N");
			//}
			if (sString == "TW") {
				if (parseFloat(sVal) > parseFloat(oPalletInfo.WeightMax)) {
					MessageBox.error(this.bundle.getText("maximumWeightReached"), {
						title: this.bundle.getText("error"),
						actions: this.bundle.getText("close"),
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
					this.getView().byId("idTotalWeight").setValue("");
					return;
					// idTotalWeight = this.getView().byId("idTotalWeight").getValue();
				}
				var oFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
					minFractionDigits: 3,
					maxFractionDigits: 3
				});
				//solutions to stop the addition of more than 3 numbers after decimal EP
				var sSepeartor = oFormatter.oFormatOptions.decimalSeparator
				if (sVal.indexOf(sSepeartor) >= 1) {
					var splitUp = sVal.split(sSepeartor, 2)
					if (splitUp[1].length > 3) {
						this.onChangeWeight();
					}
				}
			} else {
				if (sVal == 0) {
					this.getView().byId("idTotalPitches").setValue("");
				} else if (parseInt(sVal) > parseInt(oPalletInfo.PitchesMax)) {
					MessageBox.error((this.bundle.getText("YouHaveExceededTheMaximumNumberOfPitchesAllowed")), {
						title: this.bundle.getText("error"),
						actions: this.bundle.getText("close"),
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
					this.getView().byId("idTotalPitches").setValue("");
				} else {
					this.getView().byId("idTotalPitches").setValue(sVal);
				}
			}
			this.totalVolumeCalculation();
		},
		onChangeWeight: function () {
			var oFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
				minFractionDigits: 3,
				maxFractionDigits: 3
			});
			var fTotalWeight = oFormatter.parse(this.getView().byId("idTotalWeight").getValue()).toString();

			if (fTotalWeight != "") {
				this.getView().byId("idTotalWeight").setValue(this.formatter.formatQuantity(fTotalWeight));
				fTotalWeight = parseFloat(fTotalWeight).toFixed(3);
			}
			this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			// this.checkWeightPitch("TW");

		},

		maxCheck: function (oEvent) {
			var _oInput = oEvent.getSource(),
				sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.oPackModel1.getPath(),
				sPackagingType = this.getView().getModel("oPackModel1").getProperty(sPath + "/PackagingType"),
				bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length,
				idC = oEvent.getParameters().id.split("-");
			if (idC[2] == "stackableId") {
				this._checkHeightForStackable(sPath, oEvent.getSource().getProperty("selectedKey"));
			} else {
				var val = _oInput.getValue(),
					p = 0,
					sPalletMax = "",
					sPlaceHolder = oEvent.getSource().mProperties.placeholder,
					bundle = this.getView().getModel("i18n").getResourceBundle(),
					valC = oEvent.getParameters().value,
					flag = true,
					height = bundle.getText("height"),
					width = bundle.getText("width"),
					length = bundle.getText("length"),
					quantity = bundle.getText("quantity"),
					aPalletInfo = this.getView().getModel("oPackModel").getProperty("/aPalletInfo");
				idC = idC[6];
				val = val.toString();
				val = val.replace(/[^0-9]+/g, '');
				val = parseInt(val, 10);
				if (val == 0 || val.toString() == "NaN") {
					val = "";
				}
				_oInput.setValue(val);
				for (p = 0; p < aPalletInfo.length; p++) {
					if (sPackagingType == aPalletInfo[p].PackagingType) {
						if (sPlaceHolder == height) {

							var valHoehe = parseInt(aPalletInfo[0].HoeheMax);
							if (oEvent.getSource().getParent().getCells()[5].getSelectedKey() === "Y") {
								if (valC > valHoehe / 2) {
									MessageBox.error(bundle.getText("heightShouldBeLessThanX") + " " + valHoehe / 2 + " cm");
									valC = "";
									_oInput.setValue("");

								}
							} else {
								if (valC > valHoehe) {
									MessageBox.error(bundle.getText("heightShouldBeLessThanX") + " " + valHoehe + " cm");
									valC = "";
									_oInput.setValue("");

								}
							}
						} else if (sPlaceHolder == width) {
							if (parseFloat(aPalletInfo[p].WidthMax) == 0) {
								//do nothing, no validation for this type
							} else if (parseFloat(aPalletInfo[p].WidthMax) > 0 && parseFloat(aPalletInfo[p].WidthMax) < parseFloat(valC)) {

								MessageBox.error(
									bundle.getText("widthShouldBeLessThanX") + " " + parseFloat(aPalletInfo[p].WidthMax) + " " + bundle.getText("extra"), {
										title: bundle.getText("error"),
										actions: bundle.getText("close"),
										styleClass: this.bCompact ? "sapUiSizeCompact" : ""
									});
								valC = "";
								_oInput.setValue(valC);
							}
						} else if (sPlaceHolder == length) {
							if (parseFloat(aPalletInfo[p].LengthMax) == 0) {
								//do nothing, no validation if == 0
							} else if (parseFloat(aPalletInfo[p].LengthMax) > 0 && parseFloat(aPalletInfo[p].LengthMax) < parseFloat(valC)) {

								MessageBox.error(
									bundle.getText("lengthShouldBeLessThanX") + " " + parseFloat(aPalletInfo[p].LengthMax) + " " + bundle.getText("extra"), {
										title: bundle.getText("error"),
										actions: bundle.getText("close"),
										styleClass: this.bCompact ? "sapUiSizeCompact" : ""
									});
								valC = "";
								_oInput.setValue(valC);
							}
						} else if (sPlaceHolder == quantity) {
							sPalletMax = this.getPackagingType(sPackagingType);
							if (this.validateQuantity(sPalletMax, valC)) {
								MessageBox.error(
									bundle.getText("maximumQuantityReached"), {
										title: bundle.getText("error"),
										actions: bundle.getText("close"),
										styleClass: this.bCompact ? "sapUiSizeCompact" : ""
									});
								valC = "";
								_oInput.setValue(valC);
							}

						}
					}
				}
				this.totalVolumeCalculation(oEvent);
			}
			this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			// this._checkSubmitBtnVisibility();                                    
		},
		_checkMinLength: function (oEvent) {

		},
		_checkHeightForStackable: function (sPath, sKey) {
			var sPackaging = this.getView().getModel("oPackModel1").getProperty(sPath),
				// sPackagingType = sPackaging.PackagingType,
				aPalletInfo = this.getView().getModel("oPackModel").getProperty("/aPalletInfo"),
				valC = parseInt(sPackaging.Height),
				bundle = this.getView().getModel("i18n").getResourceBundle(),
				valHoehe = parseInt(aPalletInfo[0].HoeheMax);
			/*oPallet = jQuery.grep(aPalletInfo, function (oObj) {
				return oObj.PackagingType == sPackagingType;
			});*/
			if (sKey == "Y") {
				if (valC > valHoehe / 2) {
					MessageBox.error(bundle.getText("heightShouldBeLessThanX") + " " + valHoehe / 2 + " cm");
					this.getView().getModel("oPackModel1").getProperty(sPath + "/Height", "");
					sPackaging.Height = "";
					// valC = "";
					// _oInput.setValue("");
					// this.totalVolumeCalculation(oEvent);
				}
			} else {
				if (valC > valHoehe) {
					MessageBox.error(bundle.getText("heightShouldBeLessThanX") + " " + valHoehe + " cm");
					this.getView().getModel("oPackModel1").getProperty(sPath + "/Height", "");
					sPackaging.Height = "";
					// valC = "";
					// _oInput.setValue("");
					// this.totalVolumeCalculation(oEvent);
				}
			}
			this._checkSubmitBtnVisibility();
		},
		getPackagingType: function (sPackagingType) {
			switch (sPackagingType) {
			case '1WPA':
				return "wpaMax";
			case 'EUPA':
				return "EupaMax";
			case 'GRID':
				return "GridMax";
			case 'OTHE':
				return "OthersMax";
			case 'OVER':
				return "OverMax";
			default:
				break;
			}
		},
		validateQuantity: function (sPalletMax, valC) {
			var fPalletMaxVal = parseFloat(this.getView().getModel("oPackModel").getProperty("/aPalletInfo/0/" + sPalletMax));
			if (fPalletMaxVal != 0 && fPalletMaxVal < valC) {
				return true;
			} else {
				return false;
			}
		},
		totalVolumeCalculation: function (oEvent) {
			var oTablModel = this.getView().getModel("oPackModel1"),
				aPalletInfo = this.getView().getModel("oPackModel").getProperty("/aPalletInfo"),
				aTPInfo = oTablModel.getData().aPalletInfo, //TabelPalletInfo
				i, iQuantity = 0,
				iLength = 0,
				iWidth = 0,
				iHeight = 0,
				fTVolume = 0,
				fTotalVolume = 0;
			for (i = 0; i < aTPInfo.length; i++) {
				if (aTPInfo[i].Quantity != "" && aTPInfo[i].Length != "" && aTPInfo[i].Width != "" && aTPInfo[i].Height != "") {
					iQuantity = parseInt(aTPInfo[i].Quantity);
					iLength = parseInt(aTPInfo[i].Length);
					iWidth = parseInt(aTPInfo[i].Width);
					iHeight = parseInt(aTPInfo[i].Height);
					fTVolume = parseFloat(((iLength * iWidth * iHeight * 0.000001) * iQuantity).toFixed(3));
					aTPInfo[i].Tvolume = fTVolume.toString();
					fTotalVolume += fTVolume;
				}
			}
			if (fTotalVolume > aPalletInfo[0].VolMax) {
				MessageBox.error(this.bundle.getText("volumeismorethanmax") + " " + parseInt(aPalletInfo[0].VolMax), {
					title: this.bundle.getText("error"),
					actions: this.bundle.getText("close"),
					styleClass: this.bCompact ? "sapUiSizeCompact" : ""
				});
				this.getView().byId("idTotalVolume").setValue("");
				var oInput = oEvent.getSource();
				oInput.setValue("");
			} else {
				this.getView().byId("idTotalVolume").setValue(this.formatter.formatQuantityVolume(fTotalVolume));
			}
			this._checkSubmitBtnVisibility();
		},
		_onPressSubmit: function () {
			this._validateSubmit();
			// this._onSubmit();
		},
		_onSubmit: function (oEvent) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				sSAP__Origin = appModel.getProperty("/oSelectedItem").SAP__Origin;
			// this._checkDeletePallet(appModel);
			this.openBusyDialog();
			if (appModel.getProperty("/BECallAction") == "CR") {
				this.oModel.read("/LoadNumberSet(Action='X',SAP__Origin='" + sSAP__Origin + "')", {
					success: function (data) {
						this.closeBusyDiaog();
						var oData = data;
						this.getView().getModel("oPackModel").setProperty("/LoadNo", oData.LoadNo.trim());
						// MessageToast.show("LoadNo:" + oData.LoadNo);
						this._onSubmitPallet();
						appModel.setProperty("/BECallAction", "");
						appModel.setProperty("/bBackMessage", false);
					}.bind(this),
					error: function (msg) {
						this.closeBusyDiaog();
						MessageToast.show("Error:" + msg);
					}.bind(this)
				});
			} else {
				oView.getModel("oPackModel").setProperty("/LoadNo", appModel.getProperty("/LoadingNo"));
				this._onSubmitPallet();
				appModel.setProperty("/BECallAction", "");
				appModel.setProperty("/bBackMessage", false);
			}

			// this._onSubmitPallet();
		},
		_checkDeletePallet: function (appModel) {
			if (appModel.getProperty("/bNavPalletDeleted")) {
				var oDeleteItems = appModel.getProperty("/aNavPalletDeletedInfo");
				//To Do #MS
			}
		},
		_onSubmitPallet: function () {
			var oNavAvis, oNavAitem = [],
				oNavAitemObj, oNavAheader, oPayload = {},
				i = 0,
				oView = this.getView(),
				sPackagingType = "",
				sPackagingTypeCode = "",
				appModel = oView.getModel("appModel"),
				oPackModel = oView.getModel("oPackModel"),
				oPackModel1 = oView.getModel("oPackModel1"),
				aPalletInfo = oPackModel1.getData().aPalletInfo,
				sPlantTransportType = oView.byId("idPlantTransport").getValue(),
				sGoodsSupplier = oView.byId("idGoodsSupplier").getValue() == "" ? ["", ""] : oView.byId("idGoodsSupplier").getValue().split("-"),
				iTotalWeight = oView.byId("idTotalWeight").getValue(),
				fTotalVolume = oView.byId("idTotalVolume").getValue(),
				sUnloadingPoint = oView.byId("idUnloadingPoint").getValue() == "-" ? ["", ""] : oView.byId("idUnloadingPoint").getValue().split(
					"-"),
				dPickupDate = appModel.getProperty("/aSelectedTabData/0/dispPickDate"),
				dArrivalDate = oView.byId("idArrDate").getValue(),
				dPickupTimeFrom = oView.byId("idPickupTimeFrom").getValue(),
				dPickupTimeTo = oView.byId("idPickupTimeTo").getValue(),
				sTextArea = oView.byId("idRemarksTA").getValue(),
				sRoute = oView.byId("idTruckType").getValue(),
				sTruckType = oView.byId("idTruckType").getValue() == "-" ? ["", ""] : oView.byId("idTruckType").getValue().split("-"), //get the first value of route
				sPlantTransport = oView.byId("idPlantTransport").getValue(), //get the first value of plant
				iTotalPitches = oView.byId("idTotalPitches").getValue(),
				sPlantName = appModel.getProperty("/oSelectedItem").PlantName,
				bStackable = oView.byId("idStackable").getSelectedKey(),
				oFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
					minFractionDigits: 3,
					maxFractionDigits: 3
				}),
				oNavAheader = {
					SAP__Origin: appModel.getProperty("/oSelectedItem").SAP__Origin,
					Vendor: appModel.getProperty("/supplier"),
					PlantTransportType: sPlantTransportType,
					ShippingMethod: appModel.getProperty("/oSelectedPlantSupp").ShipingMethod,
					GoodsSupplier: sGoodsSupplier[0],
					GoodsSupplierDesc: sGoodsSupplier[1],
					Weight: oFormatter.parse(iTotalWeight).toString(),
					WeightUnit: "",
					Gridb: "",
					wayp: "",
					Eupallets: "",
					UnloadingPoint: sUnloadingPoint[0].trim(),
					UnloadingDescr: sUnloadingPoint[1].trim(),
					Stackable: bStackable,
					Oversize: "",
					TotalVolume: oFormatter.parse(fTotalVolume).toString(),
					ShippingType: "",
					DateOfArrival: dArrivalDate,
					TimeFrom: dPickupTimeFrom,
					TimeTo: dPickupTimeTo,
					PlantName: sPlantName,
					Comments: "", //remarks,
					Route: sRoute,
					TruckType: sTruckType[0].trim(),
					TruckTypDescr: sTruckType[1].trim(),
					LoadNo: oPackModel.getProperty("/LoadNo"),
					Loading: oPackModel.getProperty("/LoadNo"),
					CreatedBy: oView.getModel("UserModel").getProperty("/user"),
					ChangeBy: appModel.getProperty("/BECallAction") == "CR" ? "" : oView.getModel("UserModel").getProperty("/user"),
					PitchNo: iTotalPitches,
					PickupDate: dPickupDate,
					Plant: appModel.getProperty("/plant"),
					PlantTransport: sPlantTransport,
					Text1: sTextArea,
					Text2: "",
					Text3: "",
					Text4: "",
					Text5: ""
				}
			oPayload.NavAitem = {};
			oPayload.NavAvis = {};
			oPayload.NavAheader = [oNavAheader];
			for (i = 0; i < aPalletInfo.length; i++) {
				sPackagingType = aPalletInfo[i].PackagingType;
				sPackagingTypeCode = this.getPackagingTypeCode(sPackagingType);
				oNavAitemObj = {
					Counter: "",
					CreatedBy: oView.getModel("UserModel").getProperty("/user"),
					Height: (parseInt(aPalletInfo[i].Height)).toString() == "NaN" ? "" : parseInt(aPalletInfo[i].Height) + "",
					Length: (parseInt(aPalletInfo[i].Length)).toString() == "NaN" ? "" : parseInt(aPalletInfo[i].Length) + "",
					Loading: oPackModel.getProperty("/LoadNo").trim(),
					PackagingType: sPackagingTypeCode,
					Quantity: (parseInt(aPalletInfo[i].Quantity)).toString() == "NaN" ? "" : parseInt(aPalletInfo[i].Quantity) + "",
					SAP__Origin: "",
					Stackability: aPalletInfo[i].Stackability,
					Tvolume: aPalletInfo[i].Tvolume,
					Volunit: "M3",
					Width: (parseInt(aPalletInfo[i].Width)).toString() == "NaN" ? "" : parseInt(aPalletInfo[i].Width) + ""
				}
				oNavAitem.push(oNavAitemObj);
			}
			oPayload.NavAitem = oNavAitem;
			oNavAvis = jQuery.grep(appModel.getProperty("/aSelectedTabData"), function (oObj) {
				oObj.LoadingNo = oPackModel.getProperty("/LoadNo");
				oObj.DeliveryQty = oFormatter.parse(oObj.DeliveryQty).toString();
				oObj.InvoiceValue = oFormatter.parse(oObj.InvoiceValue).toString() == "NaN" ? "" : oFormatter.parse(oObj.InvoiceValue).toString();
				delete oObj.__metadata;
				delete oObj.type;
				delete oObj.bChangeFlag;
				delete oObj.bCreateFlag;
				delete oObj.dispPickDate;
				delete oObj.bEnabled;
				delete oObj.iTblIndex;
				delete oObj.iIndex
				delete oObj.class;
				delete oObj.tooltip;
				delete oObj.bEditable;
				appModel.getProperty("/bTurkishPlant") ? oObj.InvDeliveryNote = oObj.DeliveryNote : '';
				return oObj;
			}.bind(this));
			oPayload.NavAvis = appModel.getProperty("/bWithoutSelect") ? [] : oNavAvis;
			oPayload.Action = appModel.getProperty("/Action");
			oPayload.SAP__Origin = appModel.getProperty("/oSelectedItem").SAP__Origin;
			this.openBusyDialog();
			this.oModel.setHeaders({
				"myetag": appModel.getProperty("/myetag")
			});
			this.oModel.create("/TransActionSet", oPayload, {
				success: function (data, oResponse) {
					this.closeBusyDiaog();
					// MessageToast.show(data.Message);
					if (data.MsgType == "Error") {
						MessageBox.error(data.Message, {
							title: this.bundle.getText("error"),
							actions: this.bundle.getText("close"),
							styleClass: this.bCompact ? "sapUiSizeCompact" : ""
						});
					} else {
						MessageBox.success(data.Message, {
							title: this.bundle.getText("success"),
							actions: [this.bundle.getText("home"), this.bundle.getText("back"), this.bundle.getText("printLable")],
							styleClass: this.bCompact ? "sapUiSizeCompact" : "",
							onClose: function (sAction) {
								var appModel = this.getView().getModel("appModel"),
									oRouter = sap.ui.core.UIComponent.getRouterFor(this);
								appModel.setProperty("/fromMainCtrl", false);
								appModel.setProperty("/fromPackCtrl", true);
								appModel.setProperty("/bWithoutSelect", false);
								appModel.setProperty("/saveSuccess", true);
								appModel.setProperty("/bLoadData", true);
								if (sAction == this.bundle.getText("home")) {
									// this.createContorllerObj = this._oMainController.oControllers['main'];
									// this.createContorllerObj.getDetail(btoa(appModel.getProperty("/supplier")), appModel.getProperty("/fromdate"), appModel
									// 	.getProperty("/todate"), appModel.getProperty("/plant"));
									oRouter.navTo("main");
								} else if (sAction == this.bundle.getText("back")) {
									this.createContorllerObj = appModel.getData().oControllers['create'];
									this.createContorllerObj.getDetail(btoa(appModel.getProperty("/supplier")), appModel.getProperty("/fromdate"), appModel
										.getProperty("/todate"), appModel.getProperty("/plant"));
									oRouter.navTo("create");
								} else if (sAction = this.bundle.getText("printLable")) {
									var languageFile = this.getView().getModel("i18n").getResourceBundle();
									var a = window.location.href;
									var b = a.split("#");
									var c = b[0];
									// var d = c.concat("#SU_SHIPPING_NOTIF-display"); su_ship_print
									var d = c.concat("#su_ship_print-display");
									// var params = this.byId("idDetailable").getModel("detailList").getData().results[0];
									var appModelData = appModel.getData();
									window.open(d + '?Plant=' + appModelData.plant + '&Mat=&Vendor=' + appModelData.supplier + "&arrDte=" +
										appModelData.aSelectedTabData[0].Arrdate +
										'&type=pack&navFrom=true', "");
								}
							}.bind(this)
						});
					}
				}.bind(this),
				error: function (oResponse) {
					this.closeBusyDiaog();
					var res = oResponse;
					MessageToast.show(res);
				}.bind(this)
			});
		},
		_validateSubmit: function () {
			var oView = this.getView(),
				bStackable = oView.byId("idStackable").getSelectedKey(),
				oPackModel1 = oView.getModel("oPackModel1"),
				aPalletInfo = oPackModel1.getData().aPalletInfo,
				iTotalPitches = oView.byId("idTotalPitches").getValue(),
				aFlag = jQuery.grep(aPalletInfo, function (oObj) {
					return oObj.Stackability == "N";
				});

			/*for (i = 0; i < aPalletInfo.length; i++) {
				if (aPalletInfo[i].Stackability == "Y") {
					iYes++;
				} else {
					iNo++;
				}

			}*/
			if (aFlag.length > 0) {
				oView.byId("idStackable").setSelectedKey("N");
			} else {
				oView.byId("idStackable").setSelectedKey("Y");
			}
			/* else if (iYes < iNo) {
							oView.byId("idStackable").setSelectedKey("N");
						}*/
			if (iTotalPitches < aPalletInfo.length) {
				MessageBox.warning(this.bundle.getText("proceedNoOfPalletMsg"), {
					title: this.bundle.getText("warning"),
					actions: [this.bundle.getText("proceed"), this.bundle.getText("cancel")],
					styleClass: this.bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						if (sAction == this.bundle.getText("proceed")) {
							this._onSubmit();
						} else {
							// throw new ValidationException();
						}
					}.bind(this)
				});
			} else {
				this._onSubmit();
			}
		},
		getPackagingTypeCode: function (sPackagingType) {
			switch (sPackagingType) {
			case "EUPA":
				return "EU";
			case "1WPA":
				return "DP";
			case "GRID":
				return "MB";
			case "OTHE":
				return "OT";
			case "OVER":
				return "OV";
			}
		},
		_validateArrDate: function () {
			this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			this._checkSubmitBtnVisibility();
		},
		_onChangeUnloadingPoint: function () {
			this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			this._checkSubmitBtnVisibility();
		},
		_onChangeTruckType: function () {
			this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			this._checkSubmitBtnVisibility();
		},
		_onTextAreaChange: function () {
			this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			// this._checkSubmitBtnVisibility();
		},
		_onTotalPitchChange: function () {
			this.getView().getModel("appModel").setProperty("/bBackMessage", true);
			// this._checkSubmitBtnVisibility();
		},
		openBusyDialog: function () {
			if (!this.busyDialog) {
				this.busyDialog = new BusyDialog();
			}
			this.busyDialog.open();
			this.busyDialog.setBusyIndicatorDelay(10000);
		},
		closeBusyDiaog: function () {
			this.busyDialog.close();
		},
		_checkSubmitBtnVisibility: function () {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				iTotalWieght = oView.byId("idTotalWeight").getValue(),
				iTotalPitches = oView.byId("idTotalPitches").getValue(),
				sSelectedKey = oView.byId("idStackable").getSelectedKey(),
				sPlantTransport = oView.byId("idPlantTransport").getValue(),
				// sGoodsSupplier = oView.byId("idGoodsSupplier").getValue(),
				dTimeFrom = oView.byId("idPickupTimeFrom").getValue(),
				dTimeTo = oView.byId("idPickupTimeTo").getValue(),
				dArrDate = oView.byId("idArrDate").getValue(),
				sUnloadingPoint = oView.byId("idUnloadingPoint").getValue(),
				sTruckType = oView.byId("idTruckType").getValue(),
				oPackModel1 = oView.getModel("oPackModel1"),
				i,
				aPalletInfo = oPackModel1.getData().aPalletInfo,
				bHeaderFlag = false,
				bPalletFlag = aPalletInfo.length > 0 ? true : false;
			// sGoodsSupplier != "" &&
			if (iTotalWieght != "" && iTotalPitches != "" && sSelectedKey != "" && sPlantTransport != "" && (dTimeFrom !=
					"") && (dTimeTo != "") && dArrDate != "" && sUnloadingPoint != "" && sTruckType != "")
				bHeaderFlag = true;
			for (i = 0; i < aPalletInfo.length; i++) {
				if (aPalletInfo[i].PackagingType == "" || aPalletInfo[i].Quantity == "" || aPalletInfo[i].Length == "" || aPalletInfo[
						i].Width == "" || aPalletInfo[i].Height == "" || aPalletInfo[i].Stackability == "") {
					bPalletFlag = false;
					break;
				}
			}
			if (bHeaderFlag && bPalletFlag) {
				appModel.setProperty("/bSubmitBtnEnabled", true);
			} else {
				appModel.setProperty("/bSubmitBtnEnabled", false);
			}
		},
		_onPressDelete: function (oEvent) {
			// MessageToast.show("Work in Progress. Development is going on!!!");
			MessageBox.warning(this.bundle.getText("deleteShipNotif"), {
				title: this.bundle.getText("warning"),
				actions: [this.bundle.getText("yes"), this.bundle.getText("cancel")],
				styleClass: this.bCompact ? "sapUiSizeCompact" : "",
				onClose: function (sAction) {
					if (sAction == this.bundle.getText("yes")) {
						this._checkDelete();
					} else {
						// throw new ValidationException();
					}
				}.bind(this)
			});
		},
		_checkDelete: function () {
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			// appModel.getProperty("/oSelectedItem").Plant
			var aFilters = this.getCheckDeleteFilters();
			this.openBusyDialog();
			this.oModel.read("/LockSet", {
				filters: aFilters,
				success: function (data) {
					this.closeBusyDiaog();
					if (data.MessageType == "E") {
						var sMsg = data.Message;
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(sMsg, {
							title: this.bundle.getText("error"),
							actions: this.bundle.getText("close"),
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						});

					} else {
						this._deleteSelected();
					}
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show(this.bundle.getText("error") + ":" + msg);
				}.bind(this)
			});
			// oModel2.read("LockSet(SAP__Origin='" + list.SAP__Origin + "',Supplier='" + btoa(list.Vendor) + "',Pickdate='" + list.PickupDate + "',LoadingNo='" + list.Loading + "')", null, ["$format=json"], true,

		},
		getCheckDeleteFilters: function () {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				sSysAlias = appModel.getProperty("/oSelectedItem/SAP__Origin"),
				sSupplier = appModel.getProperty("/supplier"),
				sPlant = appModel.getProperty("/oSelectedItem/Plant"),
				dPickupDate = appModel.getProperty("/aSelectedTabData/0/dispPickDate"),
				sLoadingNumber = appModel.getProperty("/LoadingNo"),
				aFilter = [];
			aFilter.push(new Filter("SAP__Origin", FilterOperator.EQ, sSysAlias));
			aFilter.push(new Filter("Supplier", FilterOperator.EQ, btoa(sSupplier)));
			// aFilter.push(new Filter("Plant", FilterOperator.EQ, sPlant));
			aFilter.push(new Filter("Pickdate", FilterOperator.EQ, dPickupDate));
			aFilter.push(new Filter("LoadingNo", FilterOperator.EQ, sLoadingNumber));
			return aFilter;
		},
		getDeleteObjFilter: function () {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				sSysAlias = appModel.getProperty("/oSelectedItem/SAP__Origin"),
				sLoadingNumber = appModel.getProperty("/LoadingNo"),
				chUser = btoa(this.getView().getModel("UserModel").getProperty("/user")),
				oObj = {};
			oObj.LoadNo = sLoadingNumber;
			oObj.Changeby = chUser;
			oObj.SAP__Origin = sSysAlias;
			return oObj;
		},
		_deleteSelected: function () {
			var oObj = this.getDeleteObjFilter();
			var bundle = this.getView().getModel("i18n").getResourceBundle();
			this.oModel.create("/DeleteTransSet", oObj, {
				success: function (data, res) {
					sap.ui.core.BusyIndicator.hide();
					// var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;
					// var bundle = self.getView().getModel("i18n").getResourceBundle();
					if (data.MessageType == "E") {
						MessageBox.error(data.Message, {
							title: this.bundle.getText("error"),
							actions: this.bundle.getText("close"),
							styleClass: this.bCompact ? "sapUiSizeCompact" : "",
							onClose: function () {
								// self.oRouter.navTo("main");
								// openInvoiceFlag = false;
							}
						});
					} else {
						MessageBox.success(bundle.getText("loadingNumber") + " " + data.LoadNo + " " + bundle.getText("wasDeleted"), {
							title: this.bundle.getText("success"),
							actions: [this.bundle.getText("close"), this.bundle.getText("home")],
							styleClass: this.bCompact ? "sapUiSizeCompact" : "",
							onClose: function (sAction) {
								var appModel = this.getView().getModel("appModel"),
									oRouter = sap.ui.core.UIComponent.getRouterFor(this);
								if (sAction == this.bundle.getText("close")) {
									appModel.setProperty("/saveSuccess", true);
									this.createContorllerObj = appModel.getData().oControllers['create'];
									this.createContorllerObj.getDetail(btoa(appModel.getProperty("/supplier")), appModel.getProperty("/fromdate"),
										appModel.getProperty("/todate"), appModel.getProperty("/plant"));
									oRouter.navTo("create");
								} else {
									this._setInitialData();
									appModel.setProperty("/fromMainCtrl", false);
									appModel.setProperty("/fromPackCtrl", false);
									appModel.setProperty("/bNextPressEnable", false);
									appModel.setProperty("/bWithoutSelect", false);
									appModel.setProperty("/bBackMessage", false);
									var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
									oRouter.navTo("main");
								}

							}.bind(this)
						});
					}
				}.bind(this),
				error: function (e) {

				}.bind(this)
			});
		}
	});
});