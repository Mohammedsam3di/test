/**
 *      File   : model/user.js
 *      Version: 2018-10-25
 */
sap.ui.define(
    [
        "jquery.sap.global",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/format/DateFormat",
    ],
    function (
        jQuery,
        JSONModel,
        DateFormat
    ) {

    "use strict";

    return {

        /**
         * Get User settings from CORE and place them in UserModel
         */
        init: function (oController,bundle) {
            var self = this;
            var oModel = null;
            var oTextBundle = null;
            var oDateFormat = null;

            if (!oController) {
              //  console.error("BSH -- Mandatory parameter 'oController' missing from function call");
                return;
            }
            oTextBundle = sap.ui.getCore().getModel("i18n");
            oDateFormat = DateFormat.getDateInstance();
            // try to get Model from current view
            oModel = oController.getView().getModel("UserModel");
            // nothing? try to get Model from Core
            if (!oModel) {
                oModel = sap.ui.getCore().getModel("UserModel");
            }
            // still nothing? Create new Model
            if (!oModel) {
                oModel = new JSONModel();
            }
            sap.ui.getCore().setModel(oModel, "UserModel");
            oController.getView().setModel(oModel, "UserModel");
            // SAP User
            oModel.setProperty("/user", sap.ushell.Container.getUser().getId());//sap.ushell.Container.getUser().getId());
            // SAP backend date format, used for oData communication
            oModel.setProperty("/dateValueFormat", "yyyyMMdd");
            // UI5 input/output date format, based on User Settings in backend
       //     oModel.setProperty("/datePattern", oDateFormat.oFormatOptions.pattern);
            // UI5 input date format - displayed to User
      //      oModel.setProperty("/datePlaceholder", oTextBundle.getText(oDateFormat.oFormatOptions.pattern.toUpperCase()));
            // SAP Language
      //      oModel.setProperty("/language", sap.ushell.Container.getUser().getLanguage());
    		/*var currDate = new Date(), dStartDate,
    			getYear = currDate.toLocaleString("default", {
						year: "numeric"
					}),
					getMonth = currDate.toLocaleString("default", {
						month: "2-digit"
					}),
					getDay = currDate.toLocaleString("default", {
						day: "2-digit"
					});
				dStartDate = getYear + "-" + getMonth + "-" + getDay;
    		oModel.setProperty("/currDate", dStartDate);*/
        }
    };
});