sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "bsh_tranship/model/model",
    "bsh_tranship/model/ApplicationModel"
], function(UIComponent, Device, models, ApplicationModel) {
    "use strict";

    return UIComponent.extend("bsh_tranship.Component", {
        metadata: {
            manifest: "json"
        },
        init: function() {
            var bundle = this.getModel("i18n").getResourceBundle();
            sap.ui.getCore().setModel(bundle, "i18n");

            UIComponent.prototype.init.apply(this, arguments);
            // set the device model
            this.setModel(models.createDeviceModel(), "device");
            this.getRouter().initialize();
            var oApplicationModel = new ApplicationModel();
            this.setModel(oApplicationModel, "appModel");
        }
    });
});