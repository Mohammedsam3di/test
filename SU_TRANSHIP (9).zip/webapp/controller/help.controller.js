sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox'
    ], function(Controller, JSONModel, MessageBox) {
    "use strict";
    return Controller.extend("bsh_tranship.controller.help", {

        onInit: function(evt) {

        },

        showHelp: function(){
            var self =  this;
            var oModelTP = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/BSHB2B/SU_APP_DOC_SRV/", true);
            oModelTP.read("/DocUrlSet(AppId='SU_TANSHIP')", {
                success: function(data) {
                    window.open(data.Url,"_blank")
                },
                error: function(msg) {
                    var bundle = self.getView().getModel("i18n").getResourceBundle();
                    var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;
                    var msgTxt = jQuery.parseJSON(msg.responseText);
                    msgTxt = msgTxt.error.message.value
                    MessageBox.error(
                          (msgTxt),
                          {
                              //title: bundle.getText("error"),
                              //actions : bundle.getText("close"),
                              styleClass: bCompact ? "sapUiSizeCompact" : ""
                          }
                  );
                }
            });
        }
    });
});