sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	'sap/m/MessageBox',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/ui/unified/DateTypeRange",
	'sap/ui/unified/CalendarLegendItem',
	'sap/ui/unified/DateRange',
	"sap/m/Dialog",
	"sap/ui/model/Sorter",
	"sap/m/Button",
	"bsh_tranship/model/formatter",
	"sap/ui/core/routing/History",
	"sap/m/BusyDialog",
	"bsh_tranship/model/constants",
	"bsh_tranship/controller/BaseController",
	"bsh_tranship/utils/ValidationException",
	"sap/m/MessageToast"
], function (Controller, JSONModel, ODataModel, MessageBox, Filter, FilterOperator, Export,
	ExportTypeCSV, DateTypeRange, CalendarLegendItem, DateRange, Dialog, Sorter, Button, formatter, History, BusyDialog, Const,
	BaseController, ValidationException, MessageToast) {
	"use strict";
	var bundle, _self, respName = [];
	var gSupplier, gFromD, gToDat, gPlant, gPickD;
	return BaseController.extend("bsh_tranship.controller.create", {
		formatter: formatter,
		onInit: function () {
			this._oMainController = this.getMainController();
			// this.setControllerObject(this, "create");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("create").attachPatternMatched(this._onObjectMatched, this);
			this.bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.oInvoiceFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
				minFractionDigits: 4,
				maxFractionDigits: 4
			});
			var readReqURL = "/sap/opu/odata/BSHP/PO_TRANSPORT_SRV;mo/";
			this.oModel = new ODataModel(readReqURL);
			//this.getView().byId("idBack").setEnabled(true);
		},
		onNavBack: function () {
			history.go(-1);
		},
		onAfterRendering: function () {
			var that = this;
			if (this.getView().byId("idScrollToTop1")) {
				$("div[id$='--dynamicPageId1-contentWrapper']").scroll(function (event) {
					if ($("div[id$='--dynamicPageId1-contentWrapper']").scrollTop() > 400) {
						that.getView().byId("idScrollToTop1").setVisible(true);
					} else {
						that.getView().byId("idScrollToTop1").setVisible(false);
					}
				});
			}
			var self = this;
			var formatDelQuant = function (oEvent) {
				var oFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
					minFractionDigits: 3,
					maxFractionDigits: 3
				});

				this.setValue(self.formatter.formatQuantity(oFormatter.parse(this.getValue()).toString()));
			}
			var formatInVal = function (oEvent) {
				var oFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
					minFractionDigits: 4,
					maxFractionDigits: 4
				});

				this.setValue(self.formatter.formatInvoice(oFormatter.parse(this.getValue()).toString()));
			}
			this.getView().byId("idDelQty").attachBrowserEvent("focusout", formatDelQuant);
			this.getView().byId("idInValue").attachBrowserEvent("focusout", formatInVal);
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			appModel.getData().oControllers['create'] = this;
		},
		/*formatDelQuant: function(oEvent){
			var sVal = this.getValue();
			// this.setValue(formatQuantity)
		},*/
		_onObjectMatched: function (oEvent) {
			/*var that = this;
			if (this.getView().byId("idScrollToTop1")) {
				$("div[id$='__xmlview2--dynamicPageId1-contentWrapper']").scroll(function (event) {
					if ($("div[id$='__xmlview2--dynamicPageId1-contentWrapper']").scrollTop() > 400) {
						that.getView().byId("idScrollToTop1").setVisible(true);
					} else {
						that.getView().byId("idScrollToTop1").setVisible(false);
					}
				});
			}*/
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			oView.byId("idPrint").setVisible(false);
			// appModel.setProperty("/bBackMessage", false);
			if (appModel.getProperty("/fromMainCtrl")) {
				var suppl = btoa(appModel.getProperty("/supplier"));
				var fromdate = appModel.getProperty("/fromdate");
				var todate = appModel.getProperty("/todate");
				var plant = appModel.getProperty("/plant");
				//#MS to be deleted later
				gSupplier = suppl;
				gFromD = fromdate;
				gToDat = todate;
				gPlant = plant;
				this.getDetail(suppl, fromdate, todate, plant);
			} else {
				// appModel.setProperty("/bBackMessage", true);
				oView.byId("calendar1").addSelectedDate(new DateRange({
					startDate: new Date(appModel.getProperty("/dCalPickUpDate"))
				}));
				this._getPrintBtnVisibility();
				/*var oTable = oView.byId("idDetailable"),
					oDetailListModel = oTable.getModel("detailList"),
					oDetailListData = oDetailListModel.getData().results,
					aRes = [];
				aRes = jQuery.grep(oDetailListData, function (oObj) {
					return oObj.LoadingNo != "";
				});
				aRes.length > 0 ? oView.byId("idPrint").setVisible(true) : oView.byId("idPrint").setVisible(false);*/
			}
		},
		getFilterString: function (aFilters) {
			var sFilterParam;
			if (!aFilters || aFilters.length == 0) {
				return;
			}
			var oFilterGroups = {},
				iFilterGroupLength = 0,
				aFilterGroup,
				sFilterParam = "",
				iFilterGroupCount = 0,
				that = this;
			//group filters by path
			jQuery.each(aFilters, function (j, oFilter) {
				if (oFilter.sPath) {
					aFilterGroup = oFilterGroups[oFilter.sPath];
					if (!aFilterGroup) {
						aFilterGroup = oFilterGroups[oFilter.sPath] = [];
						iFilterGroupLength++;
					}
				} else {
					aFilterGroup = oFilterGroups["__multiFilter"];
					if (!aFilterGroup) {
						aFilterGroup = oFilterGroups["__multiFilter"] = [];
						iFilterGroupLength++;
					}
				}
				aFilterGroup.push(oFilter);
			});
			jQuery.each(oFilterGroups, function (sPath, aFilterGroup) {
				if (aFilterGroup.length > 1) {
					sFilterParam += '(';
				}
				jQuery.each(aFilterGroup, function (i, oFilter) {
					if (oFilter.sOperator) {
						if (oFilter.aValues.length > 1) {
							sFilterParam += '(';
						}
						jQuery.each(oFilter.aValues, function (i, oFilterSegment) {
							if (i > 0) {
								if (oFilter.bAND) {
									sFilterParam += " and ";
								} else {
									sFilterParam += " or ";
								}
							}
							sFilterParam = that.createFilterSegment(oFilter.sPath, oFilterSegment.operator, oFilterSegment.value1, oFilterSegment.value2,
								sFilterParam);
						});
						if (oFilter.aValues.length > 1) {
							sFilterParam += ')';
						}
					} else if (oFilter._bMultiFilter) {
						sFilterParam += that.resolveMultiFilter(oFilter);
					} else {
						sFilterParam = that.createFilterSegment(oFilter.sPath, oFilter.sOperator, oFilter.oValue1, oFilter.oValue2, sFilterParam);
					}
					if (i < aFilterGroup.length - 1) {
						sFilterParam += " or ";
					}
				});
				if (aFilterGroup.length > 1) {
					sFilterParam += ')';
				}
				if (iFilterGroupCount < iFilterGroupLength - 1) {
					sFilterParam += " and ";
				}
				iFilterGroupCount++;
			});
			return sFilterParam;
		},
		resolveMultiFilter: function (oMultiFilter) {
			var that = this,
				aFilters = oMultiFilter.aFilters,
				sFilterParam = "";

			if (aFilters) {
				sFilterParam += "(";
				jQuery.each(aFilters, function (i, oFilter) {
					if (oFilter._bMultiFilter) {
						sFilterParam += that.resolveMultiFilter(oFilter);
					} else if (oFilter.sPath) {
						sFilterParam += that.createFilterSegment(oFilter.sPath, oFilter.sOperator, oFilter.oValue1, oFilter.oValue2, "");
					}
					if (i < (aFilters.length - 1)) {
						if (oMultiFilter.bAnd) {
							sFilterParam += " and ";
						} else {
							sFilterParam += " or ";
						}
					}
				});
				sFilterParam += ")";
			}

			return sFilterParam;
		},
		createFilterSegment: function (sPath, sOperator, oValue1, oValue2, sFilterParam) {
			//if (oValue1) {
			oValue1 = "'" + oValue1 + "'";
			//}
			if (oValue2) {
				oValue2 = "'" + oValue2 + "'";
			}
			switch (sOperator) {
			case "EQ":
			case "NE":
			case "GT":
			case "GE":
			case "LT":
			case "LE":
				sFilterParam += sPath + " " + sOperator.toLowerCase() + " " + oValue1;
				break;
			case "BT":
				sFilterParam += "(" + sPath + " ge " + oValue1 + " and " + sPath + " le " + oValue2 + ")";
				break;
			case "Contains":
				sFilterParam += "substringof(" + oValue1 + "," + sPath + ")";
				break;
			case "StartsWith":
				sFilterParam += "startswith(" + sPath + "," + oValue1 + ")";
				break;
			case "EndsWith":
				sFilterParam += "endswith(" + sPath + "," + oValue1 + ")";
				break;
			default:
				sFilterParam += "true";
			}
			return sFilterParam;
		},
		getDetail: function (suppl, fromdate, todate, plant) {
			var readEntity = "/AvisDetailSet",
				oPromise = jQuery.Deferred(),
				oView = this.getView(),
				aSortData = [],
				appModel = oView.getModel("appModel");
			this.openBusyDialog();
			this.getView().byId("idNextPack").setEnabled(false);
			this.oModel.read(readEntity, {
				filters: [
					new Filter({
						path: "Supplier",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: suppl,
					}),
					new Filter({
						path: "PickDateFrom",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: fromdate,
					}),
					new Filter({
						path: "PickDateTo",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: todate,
					}),
					new Filter({
						path: "Plant",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: plant,
					}),
					new Filter({
						path: "GoodSupplier",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: appModel.getProperty("/oSelectedItem/GSvalue").split("-")[0].trim()
					})
				],
				success: function (data) {
					this.closeBusyDiaog();
					var oData = data.results,
						aTableData = {
							"results": []
						};
					this.oModelPf1Det = new JSONModel(aTableData);
					oView.byId("idDetailable").setModel(this.oModelPf1Det, "detailList");
					this.oModelPf1Det.refresh();
					if (oData.length == 1 && oData[0].Message != "") {
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						MessageBox.error(oData[0].Message, {
							actions: MessageBox.Action.OK,
							emphasizedAction: MessageBox.Action.OK,
							onClose: function () {
								oRouter.navTo("main");
							}
						});

					} else if (data.results.length > 0) {
						var oCal1 = this.byId("calendar1");
						oCal1.removeAllSpecialDates();
						if (appModel.getProperty("/bTurkishPlant")) {
							this.oModel.read("/InvCurrencySet", {
								success: function (data) {
									var aData = data;
									appModel.setProperty("/aCurrencyCollection", data.results);
								}.bind(this),
								error: function (msg) {}
							});
						}

						/*aSortData = data.results.slice();
						aSortData.sort((a, b) => a.PickupDate - b.PickupDate);
						aSortData.sort((a, b) => {
							// First, compare by PickupDate
							if (a.PickupDate < b.PickupDate) return -1;
							if (a.PickupDate > b.PickupDate) return 1;

							// If PickupDate is the same, compare by Material
							if (a.Material < b.Material) return -1;
							if (a.Material > b.Material) return 1;

							// If both PickupDate and Material are the same, return 0
							return 0;
						});
						var nRefDate = aSortData[0].PickupDate;*/
						var nRefDate = data.results[0].PickupDate;
						nRefDate = nRefDate.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3');
						oView.byId("calendar1").displayDate(new Date(nRefDate));
						var itemsText = this.bundle.getText("scheduleLines");
						oView.byId("idTablTitleDet").setText(itemsText + " (" + data.results.length + ")");
						appModel.setProperty("/aTableData", data.results);
						// appModel.setProperty("/aTableOriginalData", $.extend([],data.results)); 
						// var aSticky = oView.byId("idDetailable").getSticky() || [];
						var aSticky = [];
						aSticky.push("ColumnHeaders");
						oView.byId("idDetailable").setSticky(aSticky);
						var sTypeVal;
						var dataInbArr = [],
							dataInbArr2 = [];
						// #MS
						// first get the unique values, assign the clr
						var aUniqueVal = [],
							resultArray = [],
							duplicateArray = [],
							bBlankFlag = false,
							bFilledFlag = false,
							sTooltip = "",
							aDuplicateVal = [],
							aTableData = appModel.getProperty("/aTableData"),
							dToday = new Date(),
							dTime = this.formatter.formatTime(dToday),
							dTodayTime = dToday.getTime();
						dToday.setTime(dTodayTime);
						/*if (dTime > "14:30") {
							var dTomo = new Date(dToday);
							dTomo.setDate(dToday.getDate() + 1);
							dTime = dTomo.getTime();
							dToday.setTime(dTime);
						}*/

						var getYear = dToday.toLocaleString("default", {
								year: "numeric"
							}),
							getMonth = dToday.toLocaleString("default", {
								month: "2-digit"
							}),
							getDay = dToday.toLocaleString("default", {
								day: "2-digit"
							});
						var sStartDate = getYear + getMonth + getDay;
						appModel.setProperty("/dToday", sStartDate);
						appModel.setProperty("/dPostToday", sStartDate);
						// dPostToday
						if (dTime > "14:30") {
							var dTomo = new Date(dToday);
							dTomo.setDate(dToday.getDate() + 1);
							dTime = dTomo.getTime();
							dToday.setTime(dTime);
							getYear = dToday.toLocaleString("default", {
								year: "numeric"
							})
							getMonth = dToday.toLocaleString("default", {
								month: "2-digit"
							})
							getDay = dToday.toLocaleString("default", {
								day: "2-digit"
							});
							sStartDate = getYear + getMonth + getDay;
							appModel.setProperty("/dPostToday", sStartDate);
						}

						jQuery.grep(aTableData, function (oObj) {
							oObj.dispPickDate = oObj.PickupDate;
							oObj.DeliveryQty = this.formatter.formatQuantity(oObj.DeliveryQty);
							oObj.InvoiceValue = this.formatter.formatInvoice(oObj.InvoiceValue);
							oObj.bEnabled = true;
							oObj.bEditable = false;
						}.bind(this));
						aUniqueVal = aTableData.filter((value, index, self) => self.map(x => x.PickupDate).indexOf(value.PickupDate) == index);
						for (var i = 0; i < aUniqueVal.length; i++) {
							duplicateArray = jQuery.grep(aTableData, function (oObj) {
								return oObj.PickupDate === aUniqueVal[i].PickupDate;
							});
							if (duplicateArray.length == 1) {
								// aUniqueVal[i].dispPickDate = aUniqueVal[i].PickupDate;
								if (aUniqueVal[i].InboundDel === "" || aUniqueVal[i].LoadingNo === "") {
									aUniqueVal[i].type = "Type02";
									sTooltip = this.bundle.getText("notStarted");
								} else {
									aUniqueVal[i].type = "Type08";
									sTooltip = this.bundle.getText("completed");
								}
								dataInbArr.push({
									PickupDate: aUniqueVal[i].PickupDate,
									sType: aUniqueVal[i].type
								});
								this.handleShowSpecialDays(dataInbArr[dataInbArr.length - 1].PickupDate, dataInbArr[dataInbArr.length - 1].sType, sTooltip);
							} else {
								for (var j = 0; j < duplicateArray.length; j++) {
									// to do type01 orange
									aUniqueVal[i].type = "";
									// aUniqueVal[i].dispPickDate = aUniqueVal[i].PickupDate;
									if (duplicateArray[j].InboundDel == "" && duplicateArray[j].LoadingNo == "") {
										bBlankFlag = true;
									} else {
										bFilledFlag = true;
									}
								}
								if (bBlankFlag && bFilledFlag) {
									jQuery.grep(duplicateArray, function (oObj) {
										oObj.type = "Type06"
									});
									dataInbArr2.push({
										PickupDate: duplicateArray[0].PickupDate,
										sType: "Type06"
									});
									this.handleShowSpecialDays(dataInbArr2[dataInbArr2.length - 1].PickupDate, dataInbArr2[dataInbArr2.length - 1].sType, this
										.bundle.getText("partiallyFulfilled"));
								} else if (bBlankFlag && !bFilledFlag) {
									// duplicateArray[j-1].type = "Type02";
									jQuery.grep(duplicateArray, function (oObj) {
										oObj.type = "Type02"
									});
									dataInbArr2.push({
										PickupDate: duplicateArray[0].PickupDate,
										sType: "Type02"
									});
									this.handleShowSpecialDays(dataInbArr2[dataInbArr2.length - 1].PickupDate, dataInbArr2[dataInbArr2.length - 1].sType, this
										.bundle.getText("notStarted"));
								} else if (!bBlankFlag && bFilledFlag) {
									jQuery.grep(duplicateArray, function (oObj) {
										oObj.type = "Type08"
									});
									dataInbArr2.push({
										PickupDate: duplicateArray[0].PickupDate,
										sType: "Type08"
									});
									this.handleShowSpecialDays(dataInbArr2[dataInbArr2.length - 1].PickupDate, dataInbArr2[dataInbArr2.length - 1].sType, this
										.bundle.getText("completed"));
								}
								bBlankFlag = false;
								bFilledFlag = false;
							}
						}
						// #MS REVIEW IT FOR ANY ERRORS THEN DELETE
						/*aTableData = {
							"results": appModel.getProperty("/aTableData")
						};*/
						jQuery.grep(aTableData, function (oObj) {
							oObj.class = "None";
							oObj.tooltip = "";
							// if (oObj.PickupDate < sStartDate && oObj.type == "Type02") {
							if (oObj.PickupDate <= sStartDate && oObj.LoadingNo == "") {
								oObj.class = "Error";
								oObj.tooltip = this.bundle.getText("indelay");
							}

						}.bind(this));

						appModel.setProperty("/aTableOriginalData", JSON.parse(JSON.stringify(data.results)));
						this.setInitialTableData(appModel.getProperty("/aTableData"));

						if (appModel.getProperty("/saveSuccess")) {
							appModel.setProperty("/saveSuccess", false);
							this.PickUpDateChng(appModel.getProperty("/dCalPickUpDate"));
						}
					} else {
						MessageBox.error(this.bundle.getText("nodatafound"));
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("main");
					}
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageBox.error(this.bundle.getText("ConnectionNotEstablished"));
					oPromise.reject(msg);
				}.bind(this)
			});
			return oPromise;
		},
		setInitialTableData: function (aTableData) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				itemsText = this.bundle.getText("scheduleLines"),
				aRes = [],
				aData,
				dToday;
			dToday = appModel.getProperty("/dToday");
			aRes = jQuery.grep(aTableData, function (oObj) {
				return (oObj.PickupDate <= dToday && (oObj.type == "Type02" || (oObj.type == "Type06" && oObj.LoadingNo == ""))) || (oObj.PickupDate >=
					dToday)
			});
			aData = {
				"results": aRes
			};
			oView.byId("idTablTitleDet").setText(itemsText + " (" + aData.results.length + ")");

			this.oModelPf1Det = new JSONModel(aData);
			oView.byId("idDetailable").setModel(this.oModelPf1Det, "detailList");
			// this.oModelPf1Det.refresh();

			// this.oModelPf1Det.setData(aData);
			// this.oModelPf1Det.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.oModelPf1Det.setSizeLimit(aData.results.length);
			this.oModelPf1Det.refresh();
		},
		getAllIndexes: function (arr, val) {
			var indexes = [],
				i = -1;
			while ((i = arr.indexOf(val, i + 1)) != -1) {
				indexes.push(i);
			}
			return indexes;
		},
		PickUpDateChng: function (oEvent) {
			if (this.getView().getModel("appModel").getProperty("/bBackMessage")) {
				var bundle = this.getView().getModel("i18n").getResourceBundle();
				this._oEventDate = oEvent.getSource().getSelectedDates()[0].getStartDate();
				MessageBox.warning(bundle.getText("backMsg"), {
					actions: [bundle.getText("ok"), MessageBox.Action.CANCEL],
					emphasizedAction: bundle.getText("ok"),
					onClose: function (sAction) {
						if (sAction == bundle.getText("ok")) {
							this.dateChange(this._oEventDate, true);
							this.getView().getModel("appModel").setProperty("/bBackMessage", false);
							this.getView().getModel("appModel").setProperty("/bLoadData", true);
						}
					}.bind(this)
				});
			} else {
				this.getView().getModel("appModel").setProperty("/bLoadData", true);
				this.dateChange(oEvent);
			}

		},
		dateChange: function (oEvent, bFlag) {
			var oStartDate = "",
				dStartDate, sStartDate, dToday = new Date(),
				dTime,
				month, aTableData, aRes = [],
				oItemType = "",
				oItem = "",
				aPromise = [],
				newArray, nRefDate, oData, oView = this.getView(),
				itemsText, appModel = oView.getModel("appModel"),
				oTable = oView.byId("idDetailable"),
				oModel3 = new JSONModel();
			if (typeof (oEvent) == "string") {
				dStartDate = oStartDate = oEvent;
				oView.byId("calendar1").displayDate(new Date(oStartDate));
				aTableData = JSON.parse(JSON.stringify(appModel.getProperty("/aTableOriginalData")));

			} else if (bFlag) {
				oStartDate = oEvent;
				aTableData = JSON.parse(JSON.stringify(appModel.getProperty("/aTableOriginalData"))); // this.getView().byId("idDetailable").getModel("detailList").getData();

				var getYear = oStartDate.toLocaleString("default", {
						year: "numeric"
					}),
					getMonth = oStartDate.toLocaleString("default", {
						month: "2-digit"
					}),
					getDay = oStartDate.toLocaleString("default", {
						day: "2-digit"
					});
				dStartDate = getYear + "-" + getMonth + "-" + getDay;
				sStartDate = getYear + getMonth + getDay;
			} else {
				oStartDate = oEvent.getSource().getSelectedDates()[0].getStartDate();
				aTableData = JSON.parse(JSON.stringify(appModel.getProperty("/aTableOriginalData"))); // this.getView().byId("idDetailable").getModel("detailList").getData();

				var getYear = oStartDate.toLocaleString("default", {
						year: "numeric"
					}),
					getMonth = oStartDate.toLocaleString("default", {
						month: "2-digit"
					}),
					getDay = oStartDate.toLocaleString("default", {
						day: "2-digit"
					});
				dStartDate = getYear + "-" + getMonth + "-" + getDay;
				sStartDate = getYear + getMonth + getDay;
			}

			newArray = aTableData.filter(function (el, iIndex) {
				nRefDate = el.PickupDate;
				nRefDate = nRefDate.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3');
				return nRefDate == dStartDate;
			});
			jQuery.grep(newArray, function (oObj, Index) {
				return oObj.iIndex = Index;
			});
			oData = {
				results: newArray
			};
			/*oModel3.setData(oData);
			oView.byId("idDetailable").setModel(oModel3, "detailList");*/
			itemsText = this.bundle.getText("scheduleLines");
			oView.byId("idTablTitleDet").setText(itemsText + " (" + oData.results.length + ")");
			dStartDate = dStartDate.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3');
			oView.byId("calendar1").addSelectedDate(new DateRange({
				startDate: new Date(dStartDate)
			}));
			dTime = dToday.getTime() - (1 * 24 * 60 * 60 * 1000);
			dToday.setTime(dTime);
			// if (oData.results.length > 0 && oStartDate > dToday) {
			if (oData.results.length > 0) {
				oView.byId("idClearCalBtn").setEnabled(true);
				appModel.setProperty("/bWithoutSelect", false);
				oView.byId("idDetailable").setMode("MultiSelect");
				oItem = oData.results[0];
				oItemType = oItem.type;
				switch (oItemType) {
				case "Type02": // not created, check for selected date
					jQuery.grep(oData.results, function (oObj) {
						oObj.bEditable = true;
					});
					oModel3.setData(oData);
					oView.byId("idDetailable").setModel(oModel3, "detailList");
					oView.byId("idPrint").setVisible(false);
					break;
				case "Type06":
					if (oItem.LoadingNo == "") {
						aRes = jQuery.grep(oData.results, function (oObj) {
							return oObj.LoadingNo != "";
						});
						oItem = aRes[0];
					} else {
						aRes.push(oItem);
					}
					this.openBusyDialog();
					aPromise.push(this.getTransportMainSet(oItem));
					Promise.all(aPromise).then(function (bFlag) {
						this.closeBusyDiaog();
						//Set the data in different function for both types
						this.setDataEditable(oData.results, bFlag[0]);
						oModel3.setData(oData);
						oView.byId("idDetailable").setModel(oModel3, "detailList");
						oTable.setSelectedItem(oTable.getItems()[aRes[0].iIndex]);
						appModel.setProperty("/bWithoutSelect", true);
						// this.getView().getModel("appModel").setProperty("/bEditable", bFlag[0]);
						this.onSelectCreate();
					}.bind(this));

					break;
				case "Type08": //green, already created
					appModel.setProperty("/bNextPressEnable", true);
					aRes = jQuery.grep(oData.results, function (oObj) {
						return oObj.LoadingNo != "";
					});
					if (oItem.PickupDate <= appModel.getProperty("/dToday")) {
						oModel3.setData(oData);
						oView.byId("idDetailable").setModel(oModel3, "detailList");
						oTable.setSelectedItem(oTable.getItems()[aRes[0].iIndex]);
						appModel.setProperty("/bWithoutSelect", true);
						this.onSelectCreate();
					} else {
						this.openBusyDialog();
						aPromise.push(this.getTransportMainSet(oData.results[0]));
						Promise.all(aPromise).then(function (bFlag) {
							this.closeBusyDiaog();
							this.setDataEditable(oData.results, bFlag[0]);
							oModel3.setData(oData);
							oView.byId("idDetailable").setModel(oModel3, "detailList");
							oTable.setSelectedItem(oTable.getItems()[aRes[0].iIndex]);
							appModel.setProperty("/bWithoutSelect", true);
							this.onSelectCreate();
						}.bind(this));
						break;
					}

				}
				/*if (oData.results[0].type !== "Type02") {
					if (oData.results[0].type == "Type06" && oData.results[0].LoadingNo == "") {
						aRes = jQuery.grep(oData.results, function (oObj) {
							return oObj.LoadingNo != "";
						});
						oTable.setSelectedItem(oTable.getItems()[aRes[0].iIndex]);
						appModel.setProperty("/bWithoutSelect", true);
					} else {
						oTable.setSelectedItem(oTable.getItems()[0]);
						appModel.setProperty("/bWithoutSelect", true);
					}

				}*/
				appModel.setProperty("/dCalPickUpDate", dStartDate);
				appModel.setProperty("/bNextPressEnable", true);
			} else {
				oModel3.setData(oData);
				oView.byId("idDetailable").setModel(oModel3, "detailList");
				oView.byId("idPrint").setVisible(false);
				appModel.setProperty("/bNextPressEnable", false);
			}
			// this.onSelectCreate();
			if (appModel.getProperty("/bTurkishPlant") && newArray.length > 0) {
				jQuery.grep(newArray, function (oObj, iIndex) {
					oObj.iTblIndex = iIndex;
				});
				var aUniqueVal = newArray.filter((value, index, self) => self.map(x => x.DeliveryNote).indexOf(value.DeliveryNote) == index),
					i = 0;
				for (i = 0; i < aUniqueVal.length; i++) {
					this._validateTurkishRows(aUniqueVal[i].iTblIndex);
				}
			}
		},
		getTransportMainSet: function (oItem) {
			var aFilter = [],
				oView = this.getView(),
				appModel = oView.getModel("appModel");
			var sSupplier = oView.getModel("appModel").getProperty("/supplier");
			aFilter.push(new Filter("Date", FilterOperator.BT, appModel.getProperty("/fromdate"), appModel.getProperty("/todate")));
			aFilter.push(new Filter("Vendor", FilterOperator.EQ, btoa(sSupplier)));
			aFilter.push(new Filter("Plant", FilterOperator.EQ, oItem.Plant));
			aFilter.push(new Filter("Loadingnumber", FilterOperator.EQ, oItem.LoadingNo));
			return new Promise(function (resolve, reject) {
				this.oModel.read("/TransportMainSet", {
					filters: aFilter,
					success: function (data) {
						if (data.results.length > 0 && parseFloat(data.results[0].ShipmentCost) == 0) {
							resolve(true);
						} else {
							resolve(false);
						}

					}.bind(this),
					error: function (msg) {
						MessageToast.show(this.bundle.getText("error") + ":" + msg);
						reject();
					}.bind(this)
				});
			}.bind(this));
		},
		onClearCal: function (oEvent) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			oView.byId("idPrevPickCheckBox").setSelected(false);
			oView.byId("calendar1").removeAllSelectedDates();
			this.setInitialTableData(appModel.getProperty("/aTableData"));
			// oView.byId("idDetailable").setModel(this.oModelPf1Det, "detailList");
			appModel.setProperty("/bNextPressEnable", false);
			oView.byId("idClearCalBtn").setEnabled(false);
		},
		onPastDataSelect: function (oEvent) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			if (oEvent.getParameter("selected")) {
				oView.byId("calendar1").removeAllSelectedDates();
				var aRes = {
					results: appModel.getProperty("/aTableData")
				}
				this.oModelPf1Det = new JSONModel(aRes);
				oView.byId("idDetailable").setModel(this.oModelPf1Det, "detailList");
				this.oModelPf1Det.refresh();
				appModel.setProperty("/bNextPressEnable", false);
				oView.byId("idClearCalBtn").setEnabled(false);
			} else {
				this.setInitialTableData(appModel.getProperty("/aTableData"));
			}
		},

		getTransportDateTimeSet: function (sFilter) {
			var aFilter = sFilter,
				oView = this.getView(),
				appModel = oView.getModel("appModel");
			this.openBusyDialog();
			return new Promise(function (resolve, reject) {
				appModel.getData().oControllers['main'].oModel.read("/TransportDateTimeSet" + aFilter, {
					// filters: aFilter,
					success: function (data) {
						this.closeBusyDiaog();
						var oData = data;
						if (oData.Message != "") {
							MessageBox.warning(oData.Message, {
								actions: MessageBox.Action.OK,
								emphasizedAction: MessageBox.Action.OK,
								onClose: function () {

								}
							});
							reject();
							throw new ValidationException();
						}
						resolve();
						// oView.getModel("oPackModel").refresh(true);
					}.bind(this),
					error: function (msg) {
						this.closeBusyDiaog();
						MessageToast.show(this.bundle.getText("error") + ":" + msg);

					}.bind(this)
				});
			}.bind(this));
		},
		setHeaderText: function (relNo, purdoc, reltype, MatNo) {
			var oUserData = this.getView().getModel('UserModel').getData();
			var title = this.bundle.getText("filter") + ": ";
			if (relNo) {
				title = title + this.bundle.getText("RelNo") + ": " + relNo + ", ";
			}
			if (purdoc) {
				title = title + this.bundle.getText("purdoc") + ": " + purdoc + ", ";
			}
			if (reltype) {
				title = title + this.bundle.getText("Releasetype") + ": " + reltype + ", ";
			}
			if (MatNo) {
				title = title + this.bundle.getText("Material") + ": " + MatNo;
			}
			this.getView().byId("idsnapedCnt").setTitle(title);
		},
		onSortDetail: function () {
			if (!this._oDialogPur) {
				this._oDialogPur = sap.ui.xmlfragment("bsh_tranship.fragments.TableDetailSort", this);
				this.getView().addDependent(this._oDialogPur);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogPur);
			this._oDialogPur.open();
		},
		handleSorting: function (oEvent) {
			var oView = this.getView();
			var oTable = this.getView().byId("idDetailable")
			var mParams = oEvent.getParameters();
			var oBinding = oTable.getBinding("items");
			var aSorters = [];
			var sPath = mParams.sortItem.getKey();
			var bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending, null));
			oBinding.sort(aSorters);
		},
		_onPressBack: function () {
			if (this.getView().getModel("appModel").getProperty("/bBackMessage")) {
				var bundle = this.getView().getModel("i18n").getResourceBundle();
				MessageBox.warning(bundle.getText("backMsg"), {
					actions: [bundle.getText("ok"), MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction == bundle.getText("ok")) {
							this.getView().getModel("appModel").setProperty("/bBackMessage", false);
							this.getView().getModel("appModel").setProperty("/bLoadData", true);
							this.navToMain();
						}
					}.bind(this)
				});
			} else {
				this.navToMain();
			}
		},
		navToMain: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("main");
			// dialog.close();
			this.getView().getModel("appModel").setProperty("/bNextPressEnable", false);
		},
		OnCancel: function () {
			var _self = this;
			var bundle = this.getView().getModel("i18n").getResourceBundle();
			var dialog = new Dialog({
				title: bundle.getText("warning"),
				type: 'Message',
				content: [
					new sap.m.Label({
						text: bundle.getText("confirmCancel")
					})
				],
				beginButton: new Button({
					text: bundle.getText("ok"),
					press: function () {
						//_self.getView().byId("idBack").setEnabled(false);
						var oRouter = sap.ui.core.UIComponent.getRouterFor(_self);
						oRouter.navTo("main");
						dialog.close();
						this.getView().getModel("appModel").setProperty("/bNextPressEnable", false);
					}.bind(this)
				}),
				endButton: new Button({
					text: bundle.getText("cancel"),
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		OnNextPress: function () {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				aTableFilteredData = oView.byId("idDetailable").getModel("detailList").getData().results,
				sPaths = oView.byId("idDetailable").getSelectedContextPaths(),
				i, aSelectedTabData = [],
				oRes = [],
				oObj = [],
				dDate = "",
				aPromise = [],
				bCreateFlag = false,
				bChangeFlag = false,
				oTable = oView.byId("idDetailable"),
				oTableModel = oTable.getModel("detailList");
			if (sPaths.length == 0) {
				MessageBox.error(this.bundle.getText("selectOneRecord"));
				return;
			}
			if (sPaths.length == 1) {
				aSelectedTabData.push(oTableModel.getProperty(sPaths[0]));
			} else {
				$.each(sPaths, function (iIndex, sPathvalue) {
					aSelectedTabData.push(oTableModel.getProperty(sPathvalue));
				});
				dDate = aSelectedTabData[0].dispPickDate;
				oRes = jQuery.grep(aSelectedTabData, function (oObj) {
					return oObj.dispPickDate !== dDate;
				})
				if (oRes.length > 0) {
					MessageBox.error(this.bundle.getText("samePickDate"));
					throw new ValidationException();
				}
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// if (appModel.getProperty("/oControllers/pack") && !appModel.getProperty("/bLoadData")) {
			// appModel.setProperty("/bLoadData", false);
			// oRouter.navTo("pack");
			// } else {
			aPromise.push(this._validatePrevPickup(aSelectedTabData));
			Promise.all(aPromise).then(function () {
				for (i = 0; i < sPaths.length; i++) {
					// aSelectedTabData.push(oTableModel.getProperty(sPaths[i]));
					if (aSelectedTabData[i].LoadingNo == "") {
						bCreateFlag = true;
						aSelectedTabData[i].bCreateFlag = true;
						aSelectedTabData[i].bChangeFlag = false;
					} else {
						bChangeFlag = true;
						aSelectedTabData[i].bCreateFlag = false;
						aSelectedTabData[i].bChangeFlag = true;
					}
				}
				appModel.setProperty("/aSelectedTabData", aSelectedTabData);
				appModel.setProperty("/fromdate", gFromD);
				appModel.setProperty("/todate", gToDat);
				appModel.setProperty("/plant", gPlant);

				oRouter.navTo("pack");
			}.bind(this));
			// }

		},
		_validatePrevPickup: function (aItem) {
			// if (oItem[0].type == "Type02") {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				aData = appModel.getProperty("/aTableData"),
				oItem = aItem[0],
				aPromise = [],
				dStartDate = oItem.PickupDate,
				dDispPickUpDate = oItem.dispPickDate,
				sMaterial = oItem.Material,
				sMsg = "",
				bEditFlag = true,
				dToday = new Date(),
				oTable = oView.byId("idDetailable"),
				oTableModel = oTable.getModel("detailList"),
				aSelectedDateData = oTableModel.getData().results,
				dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				}),
				/*aRes = jQuery.grep(aData, function (oObj) {
					return oObj.type != "Type08" && dateFormat.parse(oObj.PickupDate) > dToday &&
						oObj.PickupDate != dStartDate &&
						dateFormat.parse(oObj.PickupDate) < dateFormat.parse(dDispPickUpDate) &&
						oObj.Material == sMaterial;
				}),*/
				//For partial and same pickupdate, same material
				aRes = jQuery.grep(aData, function (oObj) {
					return dateFormat.parse(oObj.PickupDate) < dateFormat.parse(dStartDate) && (oObj.type == "Type02" || (oObj.type == "Type06" &&
						oObj.LoadingNo == "")) && oObj.Material == sMaterial;
				}),
				/*aRes = jQuery.grep(aData, function (oObj) {
					return dateFormat.parse(oObj.PickupDate) < dateFormat.parse(dStartDate) && oObj.type == "Type02" && oObj.Material == sMaterial;
				}),*/
				aRes1 = jQuery.grep(aData, function (oObj) {
					return oObj.PickupDate == oItem.dispPickDate && oObj.LoadingNo != "";
				});
			if (aRes1.length > 0 && aRes1[0].PickupDate != oItem.PickupDate && aRes1[0].Material == oItem.Material) { // allow to add the qty into future created 
				this.throwExistingValidation(oItem);
			}
			// if (oItem.type == "Type02" && aRes.length > 0) { != "Type08"
			if ((oItem.type == "Type02" && aRes.length > 0)) {
				sMsg = this.bundle.getText("prevPickuporderexist") + sMaterial + this.bundle.getText("selectedDate") + " (" + this.formatter.formatDate(
					aRes[0]
					.PickupDate) + ")";
				MessageBox.error(sMsg);
				throw new ValidationException();
			}
			switch (oItem.type) {
			case "Type02": // not created, check for selected date
				if (oItem.dispPickDate == oItem.PickupDate) {
					appModel.setProperty("/LoadingNo", "");
					appModel.setProperty("/BECallAction", "CR"); //Required to generate a new loading number
					appModel.setProperty("/Action", "CR");
				} else {
					if (aRes1.length > 0) {
						oItem.LoadingNo = aRes1[0].LoadingNo.trim();
						appModel.setProperty("/LoadingNo", aRes1[0].LoadingNo.trim());
						appModel.setProperty("/Action", "CH");
						this.openBusyDialog();
						aPromise.push(this.getTransportMainSet(aRes1[0]));
						Promise.all(aPromise).then(function (bFlag) {
							this.closeBusyDiaog();
							this.getView().getModel("appModel").setProperty("/bEditable", bFlag[0]);
						}.bind(this));
					} else {
						appModel.setProperty("/LoadingNo", "");
						appModel.setProperty("/BECallAction", "CR"); //Required to generate a new loading number
						appModel.setProperty("/Action", "CR");
						appModel.setProperty("/bEditable", true);
					}
				}
				break;
			case "Type06": // created, but check for selected pickup date
				/*if (aItem.length > 1 && aItem.filter(x=> x.LoadingNo != "").length > 0) {
					var aPartialData = jQuery.grep(aItem, function (oObj) {
						return oObj.InboundDel == "";
					});
					if (aPartialData.length != 0) {
						this.throwExistingValidation(oItem);
					}
				}*/
				if (aItem.length > 1 && aItem.filter(x => x.Material == oItem.Material).length > 1) {
					this.throwExistingValidation(oItem);
				} else if (oItem.dispPickDate == oItem.PickupDate && aRes1[0].Material == oItem.Material && oItem.LoadingNo == "") {
					this.throwExistingValidation(oItem);
				}
				var aResLoading = aItem.filter(x => x.LoadingNo != "");
				if (aResLoading.length > 0) {
					if (dStartDate <= appModel.getProperty("/dPostToday")) {
						bEditFlag = false;
						appModel.setProperty("/bEditable", false);
					}
					appModel.setProperty("/LoadingNo", aResLoading[0].LoadingNo);
					appModel.setProperty("/Action", "CH");
				} else if (aRes1.length > 0) {
					appModel.setProperty("/LoadingNo", aRes1[0].LoadingNo);
					appModel.setProperty("/Action", "CH");
				} else {
					if (oItem.dispPickDate == oItem.PickupDate && aRes1[0].Material == oItem.Material) {
						this.throwExistingValidation(oItem);
					} else {
						var aItemData = jQuery.grep(aData, function (oObj) {
							return oObj.PickupDate == oItem.dispPickDate && oObj.LoadingNo != "" && oItem.Material == oObj.Material;
						});
						if (aItemData.length > 0) {
							this.throwExistingValidation(oItem);
						} else {
							appModel.setProperty("/LoadingNo", "");
							appModel.setProperty("/BECallAction", "CR"); //Required to generate a new loading number
							appModel.setProperty("/Action", "CR");
						}
					}
				}
				break;
			case "Type08": //green, already created, only change
				if (dStartDate < appModel.getProperty("/dToday")) {
					bEditFlag = false;
					appModel.setProperty("/bEditable", false);
				}
				appModel.setProperty("/LoadingNo", oItem.LoadingNo.trim());
				appModel.setProperty("/Action", "CH");
				break;
			}

			var sFilter = "(SAP__Origin='" + oItem.SAP__Origin + "',Vendor='" + btoa(oItem.Supplier) + "',Plant='" + oItem.Plant +
				"',PickUpDate='" + oItem.dispPickDate + "',ArrivalDate='',ShippingMethod='" + oItem.ShippingMethod +
				"',Route='',LoadingNo='" + oItem.LoadingNo + "',GoodSupplier='',SupplierUserId='" + btoa(this._oMainController.getView().getModel(
					"UserModel").getProperty(
					"/user")) +
				"',CreateInd='X')";
			if (bEditFlag == false) {
				return Promise.resolve();
			}

			return this.getTransportDateTimeSet(sFilter, bEditFlag);
		},
		onSelectCreate: function (oEvent) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				oTable = oView.byId("idDetailable"),
				oDetailListModel = oTable.getModel("detailList");
			this._getPrintBtnVisibility();
			/*oDetailListData = oDetailListModel.getData().results,
				aRes = [];
			aRes = jQuery.grep(oDetailListData, function (oObj) {
				return oObj.LoadingNo != "";
			});
			aRes.length > 0 ? oView.byId("idPrint").setVisible(true) : oView.byId("idPrint").setVisible(false);*/
			if (oTable.getSelectedItems().length > 0 && appModel.getProperty("/bNextPressEnable")) {
				var aItems = oTable.getSelectedItems(),
					i = 0,
					bFlag = false,
					oObj, sPath;
				if (appModel.getProperty("/bTurkishPlant")) {
					for (i = 0; i < aItems.length; i++) {
						sPath = aItems[i].getBindingContext("detailList").getPath();
						oObj = oDetailListModel.getProperty(sPath);
						if (oObj.DeliveryQty != "" && oObj.DeliveryNote != "" && oObj.InvoiceDate != "" && oObj.InvoiceValue != "" && oObj.Currency !=
							"" && (oObj.ProdDatefc ? oObj.ProdDate != "" : true)) {
							this.getView().byId("idNextPack").setEnabled(true);
						} else {
							this.getView().byId("idNextPack").setEnabled(false);
						}
					}
				} else {
					for (i = 0; i < aItems.length; i++) {
						sPath = aItems[i].getBindingContext("detailList").getPath();
						oObj = oDetailListModel.getProperty(sPath);
						if ((oObj.ProdDatefc ? oObj.ProdDate != "" : true)) {
							bFlag = true;
						} else {
							bFlag = false;
							break;
						}
					}
					this.getView().byId("idNextPack").setEnabled(bFlag);
				}

			} else {
				this.getView().byId("idNextPack").setEnabled(false);
			}
		},
		_validateTurkishRows: function (iIndex) {
			var oView = this.getView(),
				oTable = oView.byId("idDetailable"),
				appModel = oView.getModel("appModel"),
				aTableFilteredData = oView.byId("idDetailable").getModel("detailList").getData().results,
				oItem = aTableFilteredData[iIndex],
				i = 0,
				oObj, bSelect = false,
				aRes = jQuery.grep(aTableFilteredData, function (oObj) {
					return oObj.DeliveryNote != "" && oObj.DeliveryNote == oItem.DeliveryNote;
				});
			if (aRes.length > 1) {
				oObj = aRes[0];
				if (oObj.DeliveryQty != "" && oObj.DeliveryNote != "" && oObj.InvoiceDate != "" && oObj.InvoiceValue != "") {
					bSelect = true;
				}
				for (i = 1; i < aRes.length; i++) {
					aRes[i].InvoiceDate = oObj.InvoiceDate;
					aRes[i].InvoiceValue = this.formatter.formatInvoice(this.oInvoiceFormatter.parse(oObj.InvoiceValue));
					aRes[i].Currency = oObj.Currency;
					aRes[i].bEnabled = false;
					bSelect ? oTable.setSelectedItem(oTable.getItems()[aRes[i].iTblIndex]) : oTable.setSelectedItem(oTable.getItems()[aRes[i].iTblIndex],
						false);
				}
			} else if (aRes.length == 1) {
				aRes[0].bEnabled = true;
			}
			oView.byId("idDetailable").getModel("detailList").refresh(true);
		},
		handleShowSpecialDays: function (oRefDate, sTypeVal, sTooltip) {
			var oCal1 = this.byId("calendar1");
			//	oLeg1 = this.byId("legend");
			//oRefDate.setDate(i);
			var nRefDate = oRefDate;
			nRefDate = nRefDate.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3');

			oCal1.addSpecialDate(new DateTypeRange({
				startDate: new Date(nRefDate),
				type: sTypeVal,
				tooltip: sTooltip
			}));
			/*
			oLeg1.addItem(new CalendarLegendItem({
				type: sType,
				text : "Placeholder"
			}));*/
		},
		pressBack: function () {
			//history.go(-1);document.location.reload(true);return false;
			var _self = this;
			var bundle = this.getView().getModel("i18n").getResourceBundle();
			var dialog = new Dialog({
				title: bundle.getText("confirm"),
				type: 'Message',
				content: [
					new sap.m.Label({
						text: bundle.getText("wanttoleave")
					})
				],
				beginButton: new Button({
					text: bundle.getText("ok"),
					press: function () {
						dialog.close();
						var oRouter = sap.ui.core.UIComponent.getRouterFor(_self);
						oRouter.navTo("main");
						// history.go(-1);
						_self.getView().getModel("appModel").setProperty("/bNextPressEnable", false);
						_self.getView().getModel("appModel").setProperty("/saveSuccess", false);
					}
				}),
				endButton: new Button({
					text: bundle.getText("cancel"),
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		checkDelQty: function (oEvent, sProp) {
			var _oInput = oEvent.getSource(),
				sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				oView = this.getView(),
				appModel = oView.getModel("appModel"),
				oTable = oView.byId("idDetailable"),
				iIndex = parseInt(sPath.split("/")[2]),
				oItem = oTable.getItems()[iIndex],
				oObj,
				detailListModel = oItem.getBindingContext("detailList").getModel(),
				sValue = _oInput.getValue(),
				oItemData = detailListModel.getData().results,
				sValCheck = sValue.toString();
			sValCheck = sValCheck.replace(/[^0-9]+/g, '');
			sValCheck = parseInt(sValCheck, 10);
			_oInput.setValue(sValCheck);
			if (sValCheck == 0 || sValCheck.toString() == "NaN") {
				sValCheck = "";
				_oInput.setValue(sValCheck);
				appModel.setProperty("/bBackMessage", true);
			}
			if (appModel.getProperty("/bTurkishPlant")) {
				oObj = oItemData[iIndex];
				if (oObj.DeliveryNote != "" && oObj.InvoiceDate != "" && oObj.InvoiceValue != "" && parseInt(oObj.InvoiceValue) != 0 && sValue !=
					"" &&
					parseInt(sValue) != 0) {
					detailListModel.setProperty(sPath + "/DeliveryQty", parseInt(sValue));
					if (appModel.getProperty("/bWithoutSelect"))
					// oTable.setSelectedItem(oTable.getItems()[0], false);
						oTable.removeSelections();
					oTable.setSelectedItem(oTable.getItems()[iIndex]);
					appModel.setProperty("/bWithoutSelect", false);
					this.onSelectCreate();
				} else {
					oTable.setSelectedItem(oTable.getItems()[iIndex], false);
					this.onSelectCreate();
				}
			} else {
				if (oItemData[iIndex].DeliveryNote != "" && sValue != "" && parseInt(sValue) != 0) {
					detailListModel.setProperty(sPath + "/DeliveryQty", parseInt(sValue));
					if (appModel.getProperty("/bWithoutSelect"))
					// oTable.setSelectedItem(oTable.getItems()[0], false);
						oTable.removeSelections();
					oTable.setSelectedItem(oTable.getItems()[iIndex]);
					appModel.setProperty("/bWithoutSelect", false);
					this.onSelectCreate();
				} else {
					oTable.setSelectedItem(oTable.getItems()[iIndex], false);
					this.onSelectCreate();
				}
			}

		},
		_onDelQtyChange: function (oEvent) {
			console.log("hi");
			/*var sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				oView = this.getView(),
				oTable = oView.byId("idDetailable"),
				iIndex = parseInt(sPath.substr(sPath.length - 1)),
				oItem = oTable.getItems()[iIndex],
				sValue = oEvent.getParameter("value"),
				oItemData = oItem.getBindingContext("detailList").getModel().getData().results;
			if (oItemData[iIndex].DeliveryNote != "" && sValue != "" && parseInt(sValue) != 0) {
				oTable.setSelectedItem(oTable.getItems()[iIndex]);
				this.onSelectCreate();
			} else {
				oTable.setSelectedItem(oTable.getItems()[iIndex], false);
				this.onSelectCreate();
			}*/
		},
		checkDelNote: function (oEvent) {
			var _oInput = oEvent.getSource(),
				sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				oView = this.getView(),
				appModel = oView.getModel("appModel"),
				oTable = oView.byId("idDetailable"),
				iIndex = parseInt(sPath.split("/")[2]),
				oItem = oTable.getItems()[iIndex],
				sValue = _oInput.getValue(),
				oItemData = oItem.getBindingContext("detailList").getModel().getData().results;
			appModel.setProperty("/bBackMessage", true);
			// if (sValue != "" && oItemData[iIndex].DeliveryQty != "" && parseInt(oItemData[iIndex].DeliveryQty) != 0 && (oItemData[iIndex].ProdDatefc ?
			// 		oItemData[iIndex].ProdDate != "" : true)) {
			if (sValue != "" && oItemData[iIndex].DeliveryQty != "" && parseInt(oItemData[iIndex].DeliveryQty) != 0) {
				if (appModel.getProperty("/bWithoutSelect"))
				// oTable.setSelectedItem(oTable.getItems()[0], false);
					oTable.removeSelections();
				oTable.setSelectedItem(oTable.getItems()[iIndex]);
				appModel.setProperty("/bWithoutSelect", false);
				this.onSelectCreate();
			} else {
				oTable.setSelectedItem(oTable.getItems()[iIndex], false);
				this.onSelectCreate();
			}
		},
		_onPickUpDateChange: function (oEvent) {
			var oView = this.getView(),
				sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				appModel = oView.getModel("appModel"),
				detailListModel = oView.byId("idDetailable").getModel("detailList"),
				sSelectedData = oEvent.getParameter("value"),
				date = new Date(oEvent.getSource().getProperty("dateValue")),
				oTable = oView.byId("idDetailable"),
				iIndex = parseInt(sPath.split("/")[2]),
				oItemData = detailListModel.getData().results,
				oItem = oTable.getItems()[iIndex],
				aRes = [],
				sMsg = "",
				oObj,
				year = date.toLocaleString("default", {
					year: "numeric"
				}),
				month = date.toLocaleString("default", {
					month: "2-digit"
				}),
				day = date.toLocaleString("default", {
					day: "2-digit"
				}),
				formattedDate = year + month + day;
			if (appModel.getProperty("/bTurkishPlant")) {
				oObj = oItemData[iIndex];
				if (oObj.DeliveryQty != "" && oObj.DeliveryNote != "" && oObj.InvoiceDate != "" && oObj.InvoiceValue != "" && parseInt(oObj.InvoiceValue) !=
					0 && (oObj.ProdDatefc ? oObj.ProdDate != "" : true)) {
					// detailListModel.setProperty(sPath + "/InvoiceDate", formattedDate);
					if (appModel.getProperty("/bWithoutSelect"))
					// oTable.setSelectedItem(oTable.getItems()[0], false);
						oTable.removeSelections();
					oTable.setSelectedItem(oTable.getItems()[iIndex]);
					appModel.setProperty("/bWithoutSelect", false);
					this.onSelectCreate();
				} else {
					oTable.setSelectedItem(oTable.getItems()[iIndex], false);
					this.onSelectCreate();
				}
			} else {
				detailListModel.setProperty(sPath + "/dispPickDate", formattedDate);
			}

			/*aRes = jQuery.grep(appModel.getProperty("/aTableData"), function (oObj) {
				return oObj.PickupDate == formattedDate && oObj.type == "Type02";
			});
			if (aRes.length > 0) {
				sMsg = "Previous pickup order exist in the selected Date (" + aRes[0].PickupDate + ")";
				MessageBox.error(sMsg);
			}*/
			// var originalDate = "9/13/23";

			// Split the original date string by '/'
			/*	var dateComponents = sSelectedData.split('/');

				// Extract year, month, and day components
				var year = dateComponents[2];
				var month = dateComponents[0];
				var day = dateComponents[1];

				// Add '20' prefix to the year if it's less than 50 (assuming all years in '20s belong to 21st century)
				if (parseInt(year) < 50) {
					year = '20' + year;
				} else {
					// Otherwise, add '19' prefix (assuming all years greater than or equal to 50 belong to 20th century)
					year = '19' + year;
				}

				// Concatenate components in the desired format
				var convertedDate = year + '/' + month + '/' + day;

				// Output the converted date
				console.log(convertedDate);*/
		},
		_onInvPickUpDateChange: function (oEvent) {
			var oView = this.getView(),
				sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				appModel = oView.getModel("appModel"),
				detailListModel = oView.byId("idDetailable").getModel("detailList"),
				sSelectedData = oEvent.getParameter("value"),
				date = new Date(oEvent.getSource().getProperty("dateValue")),
				oTable = oView.byId("idDetailable"),
				iIndex = parseInt(sPath.split("/")[2]),
				oItemData = detailListModel.getData().results,
				oItem = oTable.getItems()[iIndex],
				aRes = [],
				sMsg = "",
				oObj,
				year = date.toLocaleString("default", {
					year: "numeric"
				}),
				month = date.toLocaleString("default", {
					month: "2-digit"
				}),
				day = date.toLocaleString("default", {
					day: "2-digit"
				}),
				formattedDate = year + month + day;
			oObj = oItemData[iIndex];
			appModel.setProperty("/bBackMessage", true);
			if (oObj.DeliveryQty != "" && oObj.DeliveryNote != "" && oObj.InvoiceDate != "" && oObj.InvoiceValue != "" && parseInt(oObj.InvoiceValue) !=
				0 && (oObj.ProdDatefc ? oObj.ProdDate != "" : true)) {
				// detailListModel.setProperty(sPath + "/InvoiceDate", formattedDate);
				if (appModel.getProperty("/bWithoutSelect"))
				// oTable.setSelectedItem(oTable.getItems()[0], false);
					oTable.removeSelections();
				oTable.setSelectedItem(oTable.getItems()[iIndex]);
				appModel.setProperty("/bWithoutSelect", false);
				this._validateTurkishRows(iIndex);
				this.onSelectCreate();
			} else {
				if (appModel.getProperty("/bWithoutSelect"))
				// oTable.setSelectedItem(oTable.getItems()[0], false);
					oTable.removeSelections();
				if (oObj.InvoiceDate == "") {
					oTable.setSelectedItem(oTable.getItems()[iIndex], false);
				} else {
					oTable.setSelectedItem(oTable.getItems()[iIndex]);
					appModel.setProperty("/bWithoutSelect", false);
				}
				this._validateTurkishRows(iIndex);
				this.onSelectCreate();
			}
		},
		_onProdDateChange: function (oEvent) {
			var oView = this.getView(),
				sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				appModel = oView.getModel("appModel"),
				detailListModel = oView.byId("idDetailable").getModel("detailList"),
				sSelectedData = oEvent.getParameter("value"),
				date = new Date(oEvent.getSource().getProperty("dateValue")),
				oTable = oView.byId("idDetailable"),
				iIndex = parseInt(sPath.split("/")[2]),
				oItemData = detailListModel.getData().results,
				oItem = oTable.getItems()[iIndex],
				aRes = [],
				sMsg = "",
				oObj,
				year = date.toLocaleString("default", {
					year: "numeric"
				}),
				month = date.toLocaleString("default", {
					month: "2-digit"
				}),
				day = date.toLocaleString("default", {
					day: "2-digit"
				}),
				formattedDate = year + month + day;
			oObj = oItemData[iIndex];
			if (oObj.dispPickDate <= formattedDate) {
				MessageBox.warning(this.bundle.getText("ProductionDateGreaterThanDeliveryDate"), {
					title: this.bundle.getText("warning"),
					actions: this.bundle.getText("close")
						// styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				oObj.ProdDate = "";
				this.onSelectCreate();
				throw new ValidationException();
			}
			appModel.setProperty("/bBackMessage", true);
			if (appModel.getProperty("/bTurkishPlant")) {
				if (oObj.DeliveryQty != "" && oObj.DeliveryNote != "" && oObj.InvoiceDate != "" && oObj.InvoiceValue != "" && oObj.ProdDate != "" &&
					oObj.Currency != "" && parseInt(oObj.InvoiceValue) != 0) {
					// detailListModel.setProperty(sPath + "/InvoiceDate", formattedDate);
					if (appModel.getProperty("/bWithoutSelect"))
					// oTable.setSelectedItem(oTable.getItems()[0], false);
						oTable.removeSelections();
					oTable.setSelectedItem(oTable.getItems()[iIndex]);
					appModel.setProperty("/bWithoutSelect", false);
					this._validateTurkishRows(iIndex);
					this.onSelectCreate();
				} else {
					if (appModel.getProperty("/bWithoutSelect"))
					// oTable.setSelectedItem(oTable.getItems()[0], false);
						oTable.removeSelections();
					if (oObj.ProdDate == "") {
						oTable.setSelectedItem(oTable.getItems()[iIndex], false);
					} else {
						oTable.setSelectedItem(oTable.getItems()[iIndex]);
						appModel.setProperty("/bWithoutSelect", false);
					}
					this._validateTurkishRows(iIndex);
					this.onSelectCreate();
				}
			} else {
				if (oObj.DeliveryQty != "" && oObj.DeliveryNote != "" && oObj.ProdDate != "") {
					// detailListModel.setProperty(sPath + "/InvoiceDate", formattedDate);
					if (appModel.getProperty("/bWithoutSelect"))
					// oTable.setSelectedItem(oTable.getItems()[0], false);
						oTable.removeSelections();
					oTable.setSelectedItem(oTable.getItems()[iIndex]);
					appModel.setProperty("/bWithoutSelect", false);
					// this._validateTurkishRows(iIndex);
					this.onSelectCreate();
				} else {
					if (appModel.getProperty("/bWithoutSelect"))
					// oTable.setSelectedItem(oTable.getItems()[0], false);
						oTable.removeSelections();
					if (oObj.ProdDate == "" || oObj.DeliveryNote == "") {
						oTable.setSelectedItem(oTable.getItems()[iIndex], false);
					} else {
						oTable.setSelectedItem(oTable.getItems()[iIndex]);
						appModel.setProperty("/bWithoutSelect", false);
					}
					// this._validateTurkishRows(iIndex);
					this.onSelectCreate();
				}
			}

		},
		_oInvNumChange: function (oEvent) { //add Copy logic in this
			var _oInput = oEvent.getSource(),
				sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				oView = this.getView(),
				appModel = oView.getModel("appModel"),
				oTable = oView.byId("idDetailable"),
				iIndex = parseInt(sPath.split("/")[2]),
				oItem = oTable.getItems()[iIndex],
				sValue = _oInput.getValue().toString().toUpperCase(),
				oObj,
				detailListModel = oItem.getBindingContext("detailList").getModel(),
				oItemData = detailListModel.getData().results;
			oObj = oItemData[iIndex];
			_oInput.setValue(sValue);
			if (oObj.DeliveryQty != "" && oObj.DeliveryNote != "" && oObj.InvoiceDate != "" && oObj.InvoiceValue != "" && parseInt(oObj.InvoiceValue) !=
				0 && (oObj.ProdDatefc ? oObj.ProdDate != "" : true)) {
				detailListModel.setProperty(sPath + "/DeliveryNote", sValue);
				if (appModel.getProperty("/bWithoutSelect"))
				// oTable.setSelectedItem(oTable.getItems()[0], false);
					oTable.removeSelections();
				oTable.setSelectedItem(oTable.getItems()[iIndex]);
				appModel.setProperty("/bWithoutSelect", false);
				this._validateTurkishRows(iIndex);
				this.onSelectCreate();
			} else {
				// oTable.setSelectedItem(oTable.getItems()[iIndex], false);
				this._validateTurkishRows(iIndex);
				this.onSelectCreate();
			}
		},
		checkInVal: function (oEvent) {
			var _oInput = oEvent.getSource(),
				sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				oView = this.getView(),
				appModel = oView.getModel("appModel"),
				oTable = oView.byId("idDetailable"),
				iIndex = parseInt(sPath.split("/")[2]),
				oItem = oTable.getItems()[iIndex],
				oObj,
				detailListModel = oItem.getBindingContext("detailList").getModel(),
				sValue = _oInput.getValue(),
				oItemData = detailListModel.getData().results,
				sValCheck = sValue.toString();
			sValCheck = sValCheck.replace(/[^0-9]+/g, '');
			sValCheck = parseInt(sValCheck, 10);
			_oInput.setValue(sValCheck);
			if (sValCheck == 0 || sValCheck.toString() == "NaN") {
				sValCheck = "";
				_oInput.setValue(sValCheck);
				appModel.setProperty("/bBackMessage", true);
			}
			oObj = oItemData[iIndex];
			if (oObj.DeliveryQty != "" && oObj.DeliveryNote != "" && oObj.InvoiceDate != "" && sValCheck != "" && (oObj.ProdDatefc ? oObj.ProdDate !=
					"" : true)) {
				// detailListModel.setProperty(sPath + "/InvoiceValue", parseInt(sValue));
				if (appModel.getProperty("/bWithoutSelect"))
				// oTable.setSelectedItem(oTable.getItems()[0], false);
					oTable.removeSelections();
				oTable.setSelectedItem(oTable.getItems()[iIndex]);
				appModel.setProperty("/bWithoutSelect", false);
				this._validateTurkishRows(iIndex);
				this.onSelectCreate();
			} else {
				if (appModel.getProperty("/bWithoutSelect"))
				// oTable.setSelectedItem(oTable.getItems()[0], false);
					oTable.removeSelections();
				if (sValCheck == "") {
					oTable.setSelectedItem(oTable.getItems()[iIndex], false);
				} else {
					oTable.setSelectedItem(oTable.getItems()[iIndex]);
					appModel.setProperty("/bWithoutSelect", false);
				}
				// oTable.setSelectedItem(oTable.getItems()[iIndex], false);
				this._validateTurkishRows(iIndex);
				this.onSelectCreate();
			}
		},
		_onCurrencyChange: function (oEvent) {
			var sPath = oEvent.getSource()._getPropertiesToPropagate().oBindingContexts.detailList.getPath(),
				iIndex = parseInt(sPath.split("/")[2]);
			this._validateTurkishRows(iIndex);
			this.onSelectCreate();
		},
		// #PRINTING
		_onPressPrint: function (oEvent) {
			// MessageToast.show("Please wait while we implement the printing feature!!");
			var languageFile = this.getView().getModel("i18n").getResourceBundle();
			var a = window.location.href;
			var b = a.split("#");
			var c = b[0];
			// var d = c.concat("#SU_SHIPPING_NOTIF-display"); su_ship_print
			var d = c.concat("#su_ship_print-display");
			var params = this.byId("idDetailable").getModel("detailList").getData().results[0];
			window.open(d + '?Plant=' + params.Plant + '&Mat=&Vendor=' + parseInt(params.Supplier, 10).toString() + "&arrDte=" + params.Arrdate +
				'&type=pack&navFrom=true', "");
		},
		throwExistingValidation: function (oItem) {
			var oTable = this.getView().byId("idDetailable"),
				oTableModel = oTable.getModel("detailList"),
				sMsg = this.bundle.getText("addQtyinExisNotif");
			MessageBox.error(sMsg);
			oItem.DeliveryNote = "";
			oTable.setSelectedItem(oTable.getItems()[oItem.iIndex], false);
			oTableModel.refresh(true);
			this.onSelectCreate();
			throw new ValidationException();
		},
		_getPrintBtnVisibility: function () {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				oTable = oView.byId("idDetailable"),
				oDetailListModel = oTable.getModel("detailList"),
				oDetailListData = oDetailListModel.getData().results,
				aRes = [];
			aRes = jQuery.grep(oDetailListData, function (oObj) {
				return oObj.LoadingNo != "" && oObj.PickupDate >= appModel.getProperty("/dToday");
			});
			oView.byId("idPrint").setVisible(false);
			if (aRes.length > 0) {
				var aItems = oTable.getSelectedItems(),
					i,
					oItem = [];
				for (i = 0; i < aRes.length; i++) {
					oItem = jQuery.grep(aItems, function (obj) {
						return oDetailListModel.getProperty(obj.getBindingContext("detailList").getPath()).iIndex == aRes[i].iIndex;
					});
					if (oItem.length > 0)
						break;
				}

				oItem.length > 0 ? oView.byId("idPrint").setVisible(true) : oView.byId("idPrint").setVisible(false);
			}
			// aRes.length > 0 ? oView.byId("idPrint").setVisible(true) : oView.byId("idPrint").setVisible(false);
		},
		setDataEditable: function (oData, bFlag) {
			var appModel = this.getView().getModel("appModel");
			jQuery.grep(oData, function (oObj) {
				if (oObj.type == "Type06" && oObj.LoadingNo != "" && oObj.PickupDate <= appModel.getProperty("/dToday")) {
					return oObj.bEditable = false;
				} else {
					return oObj.bEditable = bFlag;
				}

			});
			appModel.setProperty("/bEditable", bFlag);
		},
		onScrollToTop: function () {
			var oPage = this.getView().byId("dynamicPageId1");
			oPage._setScrollPosition(0);
		},
		openBusyDialog: function () {
			if (!this.busyDialog) {
				this.busyDialog = new BusyDialog();
			}
			this.busyDialog.open();
			this.busyDialog.setBusyIndicatorDelay(10000);
		},
		closeBusyDiaog: function () {
			this.busyDialog.close();
		}
	});
});