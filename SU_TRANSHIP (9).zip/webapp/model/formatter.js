/**
 *      model/formatter.js
 *      Version: 2018-10-26
 */
sap.ui.define([
		"sap/ui/core/format/DateFormat",
		"sap/ui/core/format/NumberFormat",
		
	],
	function (DateFormat, NumberFormat) {

		"use strict";

		var oDateFormatter = null;
		var oNumberFormatter = null;
		var oAmountFormatter = null;
		var oQuantityFormatter = null;
		var oTextBundle = null;

		return {

			/**
			 * Format Date (output) according to User specific settings
			 */
			formatDate: function (date) {
				var dDate = null;
				this.oDateFormat ? true : this.oDateFormat = DateFormat.getDateInstance();

				if (!date || date === "00000000" || date === "") {
					return "";
				}

				// is it a SAP date format - yyyyMMdd
				if (date.constructor === String && date.length == 8 && !isNaN(date)) {
					var iYear = parseInt(date.substring(0, 4));
					var iMonth = parseInt(date.substring(4, 6)) - 1; // Months are counted from 0
					var iDay = parseInt(date.substring(6, 8));
					dDate = new Date(iYear, iMonth, iDay);
				} else {
					dDate = new Date(date);
				}

				if (!dDate) {
					return "";
				}

				return this.oDateFormat.format(dDate);

			},

			/**
			 * Get Date Placeholder (used in DatePicker) according to User specific settings and Language
			 */
			getDatePlaceholder: function () {
				this.oTextBundle ? true : this.oTextBundle = sap.ui.getCore().getModel("i18n");
				this.oDateFormat ? true : this.oDateFormat = DateFormat.getDateInstance();
				return this.oTextBundle.getText(this.oDateFormat.oFormatOptions.pattern.toUpperCase());
			},

			/**
			 * Get Date Placeholder (used in DatePicker) according to User specific settings and Language
			 */
			getDateDisplayFormat: function () {
				this.oDateFormat ? true : this.oDateFormat = DateFormat.getDateInstance();
				return this.oDateFormat.oFormatOptions.pattern;
			},

			/**
			 * Format Value to ALPHA Output (remove leading zeros)
			 */
			formatAlpha: function (sValue) {
				if (sValue) {
					return sValue.toString().replace(/^0+/, "");
				} else {
					return "";
				}
			},

			/**
			 * Format Number (output) according to User specific settings
			 */
			formatNumber: function (value) {
				var sValue = "";
				var fValue = 0.0;

				this.oNumberFormatter ? true : this.oNumberFormatter = NumberFormat.getFloatInstance();

				if (!value) {
					return "";
				}

				fValue = parseFloat(value);
				return this.oNumberFormatter.format(fValue);
			},

			/**
			 * Convert String into a Float according to User specific settings
			 */
			parseNumber: function (sValue) {
				var fValue = 0.0;

				this.oNumberFormatter ? true : this.oNumberFormatter = NumberFormat.getFloatInstance();

				if (!sValue) {
					return 0;
				}

				// remove all non-numerical characters, except space, dot and comma
				sValue = sValue.replace(/[^\d,\. ]/g, "");
				return this.oNumberFormatter.parse(sValue);
			},

			/**
			 * Format Amount (output) according to User specific settings
			 * Optional parameter: Currency
			 */
			formatAmount: function (amount, currency) {
				var sAmount = "";
				var fAmount = 0.0;

				if (!amount) {
					return "";
				}

				if (!this.oAmountFormatter) {
					this.oAmountFormatter = NumberFormat.getFloatInstance();
					this.oAmountFormatter.oFormatOptions.minFractionDigits = 2;
					this.oAmountFormatter.oFormatOptions.maxFractionDigits = 2;
				}

				fAmount = parseFloat(amount);
				sAmount = this.oAmountFormatter.format(fAmount);

				if (currency) {
					return sAmount + " " + currency;
				} else {
					return sAmount;
				}

			},

			/**
			 * Format Quantity (output) according to User specific settings
			 * Optional parameter: Unit of Measurement
			 */
			formatQuantity: function (quantity, unit, fraction) {
				var sQuantity = "";
				var fQuantity = 0.0;

				if (!quantity) {
					return "";
				}

				if (!fraction) {
					fraction = 3;
				}

				if (!this.oQuantityFormatter) {
					this.oQuantityFormatter = NumberFormat.getFloatInstance();
					this.oQuantityFormatter.oFormatOptions.minFractionDigits = 3;
					this.oQuantityFormatter.oFormatOptions.maxFractionDigits = 3;
				}

				if (fraction) {
					//this.oQuantityFormatter = NumberFormat.getFloatInstance();
					this.oQuantityFormatter.oFormatOptions.minFractionDigits = fraction;
					this.oQuantityFormatter.oFormatOptions.maxFractionDigits = fraction;
				}

				fQuantity = parseFloat(quantity);
				sQuantity = this.oQuantityFormatter.format(fQuantity);

				if (unit) {
					sQuantity = sQuantity + " " + unit;
				}

				return sQuantity;

			},

			formatInvoice: function (quantity, unit, fraction) {
				var sQuantity = "";
				var fQuantity = 0.0;

				if (!quantity) {
					return "";
				}

				if (!fraction) {
					fraction = 4;
				}

				if (!this.oQuantityFormatter) {
					this.oQuantityFormatter = NumberFormat.getFloatInstance();
					this.oQuantityFormatter.oFormatOptions.minFractionDigits = 4;
					this.oQuantityFormatter.oFormatOptions.maxFractionDigits = 4;
				}

				if (fraction) {
					//this.oQuantityFormatter = NumberFormat.getFloatInstance();
					this.oQuantityFormatter.oFormatOptions.minFractionDigits = fraction;
					this.oQuantityFormatter.oFormatOptions.maxFractionDigits = fraction;
				}

				fQuantity = parseFloat(quantity);
				sQuantity = this.oQuantityFormatter.format(fQuantity);

				if (unit) {
					sQuantity = sQuantity + " " + unit;
				}

				return sQuantity;

			},

			formatQuantityVolume: function (quantity, unit, fraction) {
				var sQuantity = "";
				var fQuantity = 0.0;

				if (!fraction) {
					fraction = 3;
				}

				if (!this.oQuantityFormatter) {
					this.oQuantityFormatter = NumberFormat.getFloatInstance();
					this.oQuantityFormatter.oFormatOptions.minFractionDigits = 3;
					this.oQuantityFormatter.oFormatOptions.maxFractionDigits = 3;
				}

				if (fraction) {
					//this.oQuantityFormatter = NumberFormat.getFloatInstance();
					this.oQuantityFormatter.oFormatOptions.minFractionDigits = fraction;
					this.oQuantityFormatter.oFormatOptions.maxFractionDigits = fraction;
				}

				fQuantity = parseFloat(quantity);
				sQuantity = this.oQuantityFormatter.format(fQuantity);

				if (unit) {
					sQuantity = sQuantity + " " + unit;
				}

				return sQuantity;

			},

			date: function (date) {

				var id1 = date;
				if (!id1) {
					return "";
				}
				var date2 = "" + id1.substring(6, 8) + "." + id1.substring(4, 6) + "." + id1.substring(0, 4);

				return date2;
			},

			stackability: function (stk) {
				var bundle = this.getView().getModel("i18n").getResourceBundle();
				if (stk == "Y") {
					return bundle.getText("yes");
				} else if (stk == "N") {
					return bundle.getText("no");
				} else {
					return "";
				}

			},

			headerValSetup: function (val) {
				// logic yet to implement
				return val;
			},

			getBackgroundColor: function (sTransportPosition) {

				if (sTransportPosition === "") {
					return "Success";

				} else {
					if (sTransportPosition < 1000) {
						return "Warning";

					} else {
						return "Information";

					}
				}
			},
			formatDelQty: function (iDelQty, iOpenQty, sLoadingNumber) {
				if (sLoadingNumber == "")
					return iOpenQty;
				return iDelQty;
			},
			formatPickupDateEdit: function (sType, bFlag, sLoadingNo) {
				if (bFlag && sLoadingNo == "")
					return true;
				return false;
			},
			formatProdDateEdit: function (sType, bFlag, sLoadingNo, bProdDatefc) {
				if (bFlag && bProdDatefc && sLoadingNo == "")
					return true;
				return false;
			},
			formatInvoiceDateEdit: function (bEnabled, bNextPressEnable) {
				// if(sType !== "Type08" && bFlag && sLoadingNo == "")
				if (bEnabled && bNextPressEnable)
					return true;
				return false;
			},
			formatPalletInputs: function (bFlag1, bFlag2) {
				if (bFlag1 && bFlag2)
					return true;
				return false;
			},
			formatTime: function (sValue) {
				var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "HH:mm" // Adjust the pattern as needed for your time format
				});

				// Format the time
				return oTimeFormat.format(sValue);
			},
			getClass: function (sClass, sMaterial) {
				if (sClass == "Error")
					this.getView().byId("relNoF").addStyleClass("suTransRedClr");
				else
					this.getView().byId("relNoF").removeStyleClass();
				return true;
			},
			dispalyPrintBtn: function (sType, bFlag, sLoadingNo, bProdDatefc) {
				// if(sType !== "Type08" && bFlag && sLoadingNo == "")
				if (bEnabled && bNextPressEnable)
					return true;
				return false;
			},
			displayDltBtn: function(sAction,aSelectedTabData, dToday){
				if(sAction == "CH" && aSelectedTabData[0].PickupDate > dToday)
				return true;
				return false;
			},
			formatDatePickup: function(sDate){
				var a = UI5Date.getInstance(2000, 0, 1);
				var b= UI5Date.getInstance(sDate);
			}
		};
	});