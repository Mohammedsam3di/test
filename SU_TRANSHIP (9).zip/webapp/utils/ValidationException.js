sap.ui.define([],
	function () {
		"use strict";
		var ValidationException = function () {};
		return ValidationException;
	});