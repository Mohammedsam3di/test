sap.ui.define([
        "sap/m/MessageBox",
    ], function(
        MessageBox
    ) {

   "use strict";

    return {

        removeDuplicates: function(aOriginalArray, sProperty) {
            var aNewArray = [];
            var oLookupObject = {};

            for (var i=0; i<aOriginalArray.length; i++) {
                if(aOriginalArray[i][sProperty] != ""){
                    oLookupObject[aOriginalArray[i][sProperty]] = aOriginalArray[i];
                }
            }

            for (i in oLookupObject) {
                aNewArray.push(oLookupObject[i]);
            }

            return aNewArray;
        },


        setDataFromUrl: function () {

            var url = window.location.href,
                sParams = "",
                sPlant = "",
                sMat = "",
                sVendor = "",
                sArrDate = "",
                sType = "",
                sOrder = "",
                aParams = url.split("?");

            if (!!aParams.length) { // if any params exists in url

                aParams = aParams.filter(function (param) {
                        return param.search("Plant") >= 0
                    });

                if (!!aParams.length) { // if parameters from another app are in params of url
                    aParams = aParams[0].split("&");

                    aParams.map(function (param) {
                        switch (param.split("=")[0]) {

                        case "Plant":
                            sPlant = param.split("=")[1];
                            break;

                        case "Mat":
                            sMat = param.split("=")[1];
                            sMat = sMat.split(",").filter(function(material) {
                              return !!material.length;
                            })
                            break;

                        case "Vendor":
                            sVendor = param.split("=")[1];
                            break;

                        case "arrDte":
                            sArrDate = param.split("=")[1];
                            break;

                        case "type":
                            sType = param.split("=")[1];
                            break;

                        case "Order":
                            sOrder = param.split("=")[1];
                            break;

                        }
                    });
                    return [sPlant, sMat, sVendor, sArrDate, sType, sOrder];
                }
            }
            return [];
        },


        /**
         * Show MessageBox with oData error
         */
        showODataError: function (oError) {
            if (!oError) {
                return;
            }
            var sText = "";

            if (oError.constructor === Object) {
                if (oError.statusText) {
                    sText = sText + oError.statusText + "\n";
                };
                if (oError.message) {
                    sText = sText + oError.message + "\n";
                };
            };
            MessageBox.error(sText);
        },


        /**
         * Success messages after Notification create
         */
        showCreateNotificationMessages: function(aData, oController) {
            var bCompact = !!oController.getView().$().closest(".sapUiSizeCompact").length;
            var sMessages = "";
            var aMessage = [];
            var aErrorMessages = [];
            var aSuccessMessages = [];


            for (var i = 0; i < aData.length; i++) {
                if (aData[i].Type === "S") {
                    aSuccessMessages.push({ Message: aData[i].Message });
                }
                if (aData[i].Type === "E") {
                    aErrorMessages.push({ Message: aData[i].Message });
                }

                for (var j = 0; j < aData[i].HeaderItem.results.length; j++) {
                    if (aData[i].HeaderItem.results[j].MessageType === "S") {
                        aSuccessMessages.push({ Message: aData[i].HeaderItem.results[j].Message });
                    }
                    if (aData[i].HeaderItem.results[j].MessageType === "E") {
                        aErrorMessages.push({ Message: aData[i].HeaderItem.results[j].Message });
                    }
                }
            }


            if (aErrorMessages.length > 0) {
                sMessages = aErrorMessages.map(function(message) {
                    return message.Message
                }).join("\n");

                MessageBox.error( sMessages, { styleClass: bCompact ? "sapUiSizeCompact" : "" } );
            };

            if (aSuccessMessages.length > 0) {
                sMessages = aSuccessMessages.map(function(message) {
                    return message.Message
                }).join("\n");

                MessageBox.success( sMessages, { styleClass: bCompact ? "sapUiSizeCompact" : "" } );
            };

        }


    }
});