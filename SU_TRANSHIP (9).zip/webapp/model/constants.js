sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function (JSONModel) {
	"use strict";

	return {

		States:{
			STATE_CREATE: "CR",
			STATE_CHANGE:"CH",
			STATE_CREATE_CHANGE:"CE"
		}

	};

});