sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/m/Token',
	"sap/ui/model/Sorter",
	"bsh_tranship/utils/utils",
	"sap/m/MessageBox",
	"bsh_tranship/model/formatter",
	"bsh_tranship/model/user",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/m/TablePersoController",
	"sap/ui/core/Fragment",
	"sap/m/BusyDialog",
	"bsh_tranship/controller/BaseController",
	"sap/m/MessageToast"
	
], function (Controller, JSONModel, ODataModel, Filter, FilterOperator, Token, Sorter, Utils, MessageBox, Formatter, UserModel, Export,
	ExportTypeCSV, TablePersoController, Fragment, BusyDialog, BaseController, MessageToast) {
	"use strict";
	var sPersonalizationContainerName = "SU_TRANSHIP";
	var oInitControllState = {};
	var gSupplier, gPickupDateF, gPickupDateT;
	var _self;
	return BaseController.extend("bsh_tranship.controller.main", {
		formatter: Formatter,
		onInit: function () {
			/*this.oControllers = {
				"main": null,
				"create": null,
				"pack": null
			};*/
			this._oMainController = this.getMainController();
			// this.setControllerObject(this, "main");
			this.bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			// UserModel.init(this, this.bundle);
			var oUserModel = this._oMainController.getView().getModel("UserModel");
			this.user = oUserModel.getProperty("/user");
			// this.user = "SAFWAN_X";
			this.initializeVariants(this);
			this.oModel = new ODataModel("/sap/opu/odata/BSHP/PO_TRANSPORT_SRV;mo/", {
				useBatch: false
			});
			this.oModel1 = new ODataModel("/sap/opu/odata/BSHP/PO_TRANSPORT_SRV", {
				useBatch: false
			});
			this.openBusyDialog(this);
			this.oModel1.read("/PickupDateSet(FieldName='AHDAT_LOW')", {
				// filters: aFilter,
				success: function (data) {
					this.closeBusyDiaog();
					var iVal = 0;
					if (data.Value) {
						iVal = parseInt(data.Value);
					}
					var currDate = new Date(),
						dStartDate,
						day = currDate.getTime() - (iVal * 24 * 60 * 60 * 1000);
					currDate.setTime(day);
					var getYear = currDate.toLocaleString("default", {
							year: "numeric"
						}),
						getMonth = currDate.toLocaleString("default", {
							month: "2-digit"
						}),
						getDay = currDate.toLocaleString("default", {
							day: "2-digit"
						});
					dStartDate = getYear + "-" + getMonth + "-" + getDay;
					oUserModel.setProperty("/currDate", dStartDate);
					oUserModel.setProperty("/minDate", currDate);
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					MessageToast.show("Error:");
				}.bind(this)
			});

		},

		onAfterRendering: function () {
			var oView = this.getView(),
				appModel = oView.getModel("appModel");
			appModel.getData().oControllers['main'] = this;
			var that = this;
			if (this.getView().byId("idScrollToTop")) {
				$("section[id$='--idCreatePage-cont']").scroll(function (event) {
					if ($("section[id$='--idCreatePage-cont']").scrollTop() > 400) {
						that.getView().byId("idScrollToTop").setVisible(true);
					} else {
						that.getView().byId("idScrollToTop").setVisible(false);
					}
				});
			}
		},
		onScrollToTop: function () {
			var oPage = this.getView().byId("idCreatePage");
			oPage.scrollTo(0, 0);
		},
		initializeVariants: function (that) {
			_self = this;
			that.getDataGl(_self.user).then(function (data) {
				if (data.results.length != 0) {
					var oVariantMgmtControl = _self.getView().byId("variantManagement");
					var oVariantModel = new sap.ui.model.json.JSONModel();
					_self.getView().setBusy(true);
					_self.getAllVariants(function (aVariants, sDefaultKey) {
						_self.getView().setBusy(false);
						oVariantModel.oData.Variants = aVariants;
						oVariantMgmtControl.setModel(oVariantModel);
						oVariantMgmtControl.setInitialSelectionKey(sDefaultKey);
						oVariantMgmtControl.setDefaultVariantKey(sDefaultKey);
						oVariantMgmtControl.fireSelect({
							key: sDefaultKey
						});
					}.bind(_self));
				}
			});
		},
		getDataGl: function (user) {
			var readReqURL = "/sap/opu/odata/BSHB2B/SU_USER_SRV/",
				oModel = new ODataModel(readReqURL),
				readEntity = "/SupplierVendorSet",
				oPromise = jQuery.Deferred(),
				oUserModel = this._oMainController.getView().getModel("UserModel");
			_self = this;
			this.openBusyDialog(this);
			if (user == "DEFAULT_USER") {
				user = "SAFWAN_X";
				oUserModel.setProperty("/user", "SAFWAN_X")
			}
			oModel.read(readEntity, {
				filters: [
					new Filter({
						path: "Bname",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: btoa(user)
							// value1: btoa("SAFWAN_X") //#MS
					}),
					new Filter({
						path: "AppId",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: "SU_TRANSHIP",
					})
				],
				success: function (data) {
					this.closeBusyDiaog();
					_self.dataGL = data;
					var oModel3 = new JSONModel();
					var vendorData = _self.removeDuplicates(data.results, "Lifnr");
					oModel3.setProperty("/results", vendorData);
					oModel3.setSizeLimit(vendorData.length);
					_self.getView().byId("supplierFrom").setModel(oModel3);
					_self.startVariants(data);
					oPromise.resolve(data);
				}.bind(this),
				error: function (msg) {
					this.closeBusyDiaog();
					_self.MessageBox("connectionError");
					oPromise.reject(msg);
				}.bind(this)
			});
			return oPromise;
		},
		removeDuplicates: function (originalArray, prop) {
			var newArray = [];
			var lookupObject = {};
			for (var i = 0; i < originalArray.length; i++) {
				if (originalArray[i][prop] != "") {
					lookupObject[originalArray[i][prop]] = originalArray[i];
				}
			}
			for (i in lookupObject) {
				newArray.push(lookupObject[i]);
			}
			return newArray;
		},
		onSearch: function () {
			this.openBusyDialog(this);
			var _self = this,
				oView = _self.getView(),
				appModel = oView.getModel("appModel"),
				sVendorId = oView.byId("supplierFrom").getSelectedKey(),
				rDateRegExp = /[^a-zA-Z0-9]/g,
				PickupDateF = oView.byId("pickupDate").getValue(),
				PickupDateT = oView.byId("pickupDateTo").getValue(),
				bCompact = !!_self.getView().$().closest(".sapUiSizeCompact").length;
			if (sVendorId === "") {
				this.getView().byId("supplierFrom").setValueState(sap.ui.core.ValueState.Error);
				MessageBox.error(_self.bundle.getText("Pleasefillintherequireddetails"), {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				this.closeBusyDiaog();
				return false;
			}
			if (PickupDateF === "") {
				this.getView().byId("pickupDate").setValueState(sap.ui.core.ValueState.Error);
				MessageBox.error(_self.bundle.getText("Pleasefillintherequireddetails"), {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				this.closeBusyDiaog();
				return false;
			} else if (PickupDateT === "") {
				var d = new Date();
				var date = d.getDate();
				var month = d.getMonth() + 1;
				var year = d.getFullYear();
				if (date < 10) date = '0' + date;
				if (month < 10) month = '0' + month;
				var toDate = year + "" + month + "" + date;
				oView.byId("pickupDateTo").setValue(toDate);
				PickupDateT = toDate;
			}
			if (new Date(PickupDateF) > new Date(PickupDateT)) {
				MessageBox.error(_self.bundle.getText("fromCannotBeGreaterThanTo"), {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				this.closeBusyDiaog();
				return false;
			}
			appModel.setProperty("/selectedDateFrom", this.formatter.formatDate(oView.byId("pickupDate").getProperty("dateValue")));
			appModel.setProperty("/selectedDateTo", this.formatter.formatDate(oView.byId("pickupDateTo").getProperty("dateValue")));
			appModel.setProperty("/minDateCal", new Date(oView.byId("pickupDate").getProperty("dateValue")));
			appModel.setProperty("/maxDateCal", new Date(oView.byId("pickupDateTo").getProperty("dateValue")));
			
			gSupplier = sVendorId;
			// this.getView().getModel("appModel").setProperty("/user", "SAFWAN_X");
			// this.getView().getModel("appModel").setProperty("/user", this.getView().getModel("UserModel").getProperty("/user"));
			oView.getModel("appModel").setProperty("/supplier", sVendorId);
			gPickupDateF = PickupDateF;
			gPickupDateT = PickupDateT;
			this.oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				format: "yyyyMMdd"
			});
			var oFilterSupplier = new Filter("Supplier", sap.ui.model.FilterOperator.EQ, btoa(sVendorId));
			var oFilterPickup = new Filter("PickDate", sap.ui.model.FilterOperator.BT, PickupDateF.replaceAll("-", ""), PickupDateT.replaceAll(
				"-", ""));
			var allFilter = [];
			allFilter = [
				new Filter({
					filters: [
						oFilterSupplier,
						oFilterPickup
					],
					and: true
				})
			];
			return new Promise(function (resolve, reject) {
				// var readReqURL = "/sap/opu/odata/BSHP/PO_TRANSPORT_SRV;mo/";
				// var oSrvCallModel1 = new ODataModel(readReqURL, true);
				var oView = this.getView(),
					appModel = oView.getModel("appModel"),
					oTable = oView.byId("idTransTable"),
					// oForm = oView.byId("idSimpleForm1"),
					oTableTitle = oView.byId("idTransTableTitle");
				this.oModel.read("/PlantDescSet", {
					filters: allFilter,
					success: function (data) {
						this.closeBusyDiaog();
						if (data.results.length) {
							if (data.results[0].ErrorLog === "") {
								var itemsText = this.bundle.getText("plantswithopenorder"),
									aSticky = oView.byId("idTransTable").getSticky() || [],
									aData = data.results;
								// _self.oModelTrans = new JSONModel(data);
								// _self.getView().byId("idTransTableTitle").setText();
								// _self.oModelTrans.setSizeLimit(data.results.length);

								oTableTitle.setText(itemsText + " (" + aData.length + ")");
								appModel.setProperty("/aPlantDescSet", aData);
								// _self.getView().byId("idTransTable").setModel(_self.oModelTrans, "detailList");
								oTable.setVisible(true);
								// oForm.setVisible(true);
								oTable.removeSelections(true);
								aSticky.push("ColumnHeaders");
								oTable.setSticky(aSticky);
								this._getGoodsSupplierData();
							} else {
								_self.showMessageBox(data.results[0].ErrorLog, true);
								oTable.setVisible(false);
							}
						} else {
							_self.showMessageBox(_self.bundle.getText("NoData"), true);
							oTable.setVisible(false);
						}
					}.bind(this),
					error: function (msg) {
						this.closeBusyDiaog();
						// sap.ui.core.BusyIndicator.hide();
						_self.showMessageBox(_self.bundle.getText("ConnectionNotEstablished"), true);
						oTable.setVisible(false);
						reject();
					}.bind(this)
				});
			}.bind(this));

		},
		_getGoodsSupplierData: function () {
			this.openBusyDialog(this);
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				aPlantData = appModel.getProperty("/aPlantDescSet");
			if (aPlantData.length > 0) {
				var aFilters = [],
					allFilter = [],
					i = 0,
					sSapOrigin, sSupplier;
				for (i = 0; i < aPlantData.length; i++) {
					aPlantData[i].bSelected = false; //for usability on selection
					aPlantData[i].GSvalue = "";
					aFilters.push(new Filter("Plant", FilterOperator.EQ, aPlantData[i].Plant));
				}
				sSapOrigin = new Filter("SAP__Origin", FilterOperator.EQ, aPlantData[0].SAP__Origin);
				sSupplier = new Filter("Supplier", FilterOperator.EQ, btoa(gSupplier));
				allFilter.push(new Filter(aFilters, false));
				allFilter.push(sSapOrigin);
				allFilter.push(sSupplier);
				this.oModel.read("/GoodSupplierSet", {
					filters: allFilter,
					success: function (data) {
						this.closeBusyDiaog();
						// console.log(data);
						appModel.setProperty("/aGoodsSupplier", data.results);
					}.bind(this),
					error: function (msg) {
						this.closeBusyDiaog();
					}.bind(this)
				});
			}
			appModel.refresh();
		},
		showMessageBox: function (msg, err) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			if (err) {
				MessageBox.error(
					_self.bundle.getText(msg), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
			} else {
				MessageBox.success(
					_self.bundle.getText(msg), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
			}
		},
		getAllVariants: function (fnCallBack) {
			var oPersonalizationVariantSet = {},
				aExistingVariants = [],
				aVariantKeysAndNames = [];

			//get the personalization service of shell
			this._oPersonalizationService = sap.ushell.Container.getService('Personalization');
			this._oPersonalizationContainer = this._oPersonalizationService.getPersonalizationContainer("MyVariantContainer");

			this._oPersonalizationContainer.fail(function () {
				// call back function in case of fail
				fnCallBack(aExistingVariants);
			});

			this._oPersonalizationContainer.done(function (oPersonalizationContainer) {
				// check if the current variant set exists, If not, add the new variant set to the container
				if (!(oPersonalizationContainer.containsVariantSet(sPersonalizationContainerName))) {
					oPersonalizationContainer.addVariantSet(sPersonalizationContainerName);
				}
				// get the variant set
				oPersonalizationVariantSet = oPersonalizationContainer.getVariantSet(sPersonalizationContainerName);
				aVariantKeysAndNames = oPersonalizationVariantSet.getVariantNamesAndKeys();
				var sDefaultKey = oPersonalizationVariantSet.getCurrentVariantKey();
				for (var key in aVariantKeysAndNames) {
					if (aVariantKeysAndNames.hasOwnProperty(key)) {
						var oVariantItemObject = {};
						oVariantItemObject.VariantKey = aVariantKeysAndNames[key];
						oVariantItemObject.VariantName = key;
						oVariantItemObject.Author = JSON.parse(
							oPersonalizationVariantSet
							.getVariant(oVariantItemObject.VariantKey)
							.getItemValue("Filter")
						).Author;
						aExistingVariants.push(oVariantItemObject);
					}
				}
				fnCallBack(aExistingVariants, sDefaultKey);
			}.bind(this));
		},
		startVariants: function (data) {
			var oVariantMgmtControl = _self.getView().byId("variantManagement");
			var oVariantModel = new sap.ui.model.json.JSONModel();
			_self.getView().setBusy(true);
			var supplierData = data;
			_self.getAllVariants(function (aVariants, sDefaultKey) {
				_self.getView().setBusy(false);

				if (aVariants.length > 0) {
					oVariantModel.oData.Variants = aVariants;
					oVariantMgmtControl.setModel(oVariantModel);
					if (sDefaultKey != "*standard*") {
						oVariantMgmtControl.setInitialSelectionKey(sDefaultKey);
					}
					oVariantMgmtControl.setDefaultVariantKey(sDefaultKey);
					oVariantMgmtControl.fireSelect({
						key: sDefaultKey
					});
				}
			}.bind(_self));
			oInitControllState = _self.prepareFilterData();
		},
		getAllVariants: function (fnCallBack) {
			var oPersonalizationVariantSet = {},
				aExistingVariants = [],
				aVariantKeysAndNames = [];

			//get the personalization service of shell
			this._oPersonalizationService = sap.ushell.Container.getService('Personalization');
			this._oPersonalizationContainer = this._oPersonalizationService.getPersonalizationContainer("MyVariantContainer");

			this._oPersonalizationContainer.fail(function () {
				// call back function in case of fail
				fnCallBack(aExistingVariants);
			});

			this._oPersonalizationContainer.done(function (oPersonalizationContainer) {
				// check if the current variant set exists, If not, add the new variant set to the container
				if (!(oPersonalizationContainer.containsVariantSet(sPersonalizationContainerName))) {
					oPersonalizationContainer.addVariantSet(sPersonalizationContainerName);
				}
				// get the variant set
				oPersonalizationVariantSet = oPersonalizationContainer.getVariantSet(sPersonalizationContainerName);
				aVariantKeysAndNames = oPersonalizationVariantSet.getVariantNamesAndKeys();
				var sDefaultKey = oPersonalizationVariantSet.getCurrentVariantKey();
				for (var key in aVariantKeysAndNames) {
					if (aVariantKeysAndNames.hasOwnProperty(key)) {
						var oVariantItemObject = {};
						oVariantItemObject.VariantKey = aVariantKeysAndNames[key];
						oVariantItemObject.VariantName = key;
						oVariantItemObject.Author = JSON.parse(
							oPersonalizationVariantSet
							.getVariant(oVariantItemObject.VariantKey)
							.getItemValue("Filter")
						).Author;
						aExistingVariants.push(oVariantItemObject);
					}
				}
				fnCallBack(aExistingVariants, sDefaultKey);
			}.bind(this));
		},
		prepareFilterData: function (appFrom) {
			var user = this._oMainController.getView().getModel("UserModel");
			var oView = this.getView();
			if (user !== undefined) {
				user = user.getData().id;
			}
			var oFilterData = {
				"filters": [],
				"Author": user
			};
			var sVendorId = oView.byId("supplierFrom");
			var PickupDateF = oView.byId("pickupDate");
			var PickupDateT = oView.byId("pickupDateTo");
			oFilterData.filters.push({
				key: 'supplierFrom',
				value: sVendorId.getSelectedKey()
			});
			oFilterData.filters.push({
				key: 'pickupDate',
				value: PickupDateF.getValue()
			});
			oFilterData.filters.push({
				key: 'pickupDateTo',
				value: PickupDateT.getValue()
			});
			return oFilterData;
		},

		onSaveAsVariant: function (oEvent) {
			var oSelectedFilterData = this.prepareFilterData();
			var bDefault = oEvent.mParameters.def;
			this.saveVariant(oEvent.mParameters.name, bDefault, oSelectedFilterData, function (bFlag, sVariantKey) {
				//refresh variants
				var oVariantMgmtControl = this.getView().byId("variantManagement");
				var oVariantModel = new sap.ui.model.json.JSONModel();
				this.getAllVariants(function (aVariants) {
					oVariantModel.oData.Variants = aVariants;
					oVariantMgmtControl.destroyVariantItems();
					oVariantMgmtControl.setModel(oVariantModel);
					oVariantMgmtControl.setInitialSelectionKey(sVariantKey);
					if (bDefault) {
						oVariantMgmtControl.setDefaultVariantKey(sVariantKey);
					}
					oVariantMgmtControl.fireSelect({
						key: sVariantKey
					});
				}.bind(this));
			}.bind(this));
		},

		saveVariant: function (sVariantName, bDefault, oFilterData, fnCallBack) {
			// save variants in personalization container
			this._oPersonalizationContainer.fail(function () {
				// call back function in case of fail
				fnCallBack(false);
			});

			this._oPersonalizationContainer.done(function (oPersonalizationContainer) {
				var oPersonalizationVariantSet = {},
					oVariant = {},
					sVariantKey = "";

				// check if the current variant set exists, If not, add the new variant set to the container
				if (!(oPersonalizationContainer.containsVariantSet(sPersonalizationContainerName))) {
					oPersonalizationContainer.addVariantSet(sPersonalizationContainerName);
				}

				// get the variant set
				oPersonalizationVariantSet = oPersonalizationContainer.getVariantSet(sPersonalizationContainerName);

				//get if the variant exists or add new variant
				sVariantKey = oPersonalizationVariantSet.getVariantKeyByName(sVariantName);
				if (sVariantKey) {
					oVariant = oPersonalizationVariantSet.getVariant(sVariantKey);
				} else {
					oVariant = oPersonalizationVariantSet.addVariant(sVariantName);
					sVariantKey = oVariant.getVariantKey();
				}

				if (bDefault) {
					oPersonalizationVariantSet.setCurrentVariantKey(sVariantKey);
				}

				if (oFilterData) {
					oVariant.setItemValue('Filter', JSON.stringify(oFilterData));
				}

				oPersonalizationContainer.save().fail(function () {
					//call callback fn with false
					fnCallBack(false);
				}).done(function () {
					//call call back with true
					fnCallBack(true, sVariantKey);
				}.bind(this));

			}.bind(this));
		},

		renameVariants: function (aRenamed, fnCallBack) {
			// save variants in personalization container
			this._oPersonalizationContainer.fail(function () {
				// call back function in case of fail
				fnCallBack(false);
			});

			this._oPersonalizationContainer.done(function (oPersonalizationContainer) {
				var oPersonalizationVariantSet = {},
					oVariant = {},
					sVariantKey = "";

				// check if the current variant set exists, If not, add the new variant set to the container
				if (!(oPersonalizationContainer.containsVariantSet(sPersonalizationContainerName))) {
					oPersonalizationContainer.addVariantSet(sPersonalizationContainerName);
				}

				// get the variant set
				oPersonalizationVariantSet = oPersonalizationContainer.getVariantSet(sPersonalizationContainerName);

				aRenamed.forEach(function (oVariant) {
					oPersonalizationVariantSet.getVariant(oVariant.key)._oVariantName = oVariant.name;
				});

				oPersonalizationContainer.save().fail(function () {
					//call callback fn with false
					fnCallBack(false);
				}).done(function () {
					//call call back with true
					fnCallBack(true);
				}.bind(this));

			}.bind(this));

		},

		setNewDefault: function (sNewDefaultVariantKey, fnCallBack) {
			// save variants in personalization container
			this._oPersonalizationContainer.fail(function () {
				// call back function in case of fail
				fnCallBack(false);
			});

			this._oPersonalizationContainer.done(function (oPersonalizationContainer) {
				var oPersonalizationVariantSet = {},
					oVariant = {},
					sVariantKey = "";

				// check if the current variant set exists, If not, add the new variant set to the container
				if (!(oPersonalizationContainer.containsVariantSet(sPersonalizationContainerName))) {
					oPersonalizationContainer.addVariantSet(sPersonalizationContainerName);
				}

				// get the variant set
				oPersonalizationVariantSet = oPersonalizationContainer.getVariantSet(sPersonalizationContainerName);

				oPersonalizationVariantSet.setCurrentVariantKey(sNewDefaultVariantKey);

				oPersonalizationContainer.save().fail(function () {
					//call callback fn with false
					fnCallBack(false);
				}).done(function () {
					//call call back with true
					fnCallBack(true);
				}.bind(this));

			}.bind(this));

		},

		onManageVariant: function (oEvent) {
			var aDeletedVariants = oEvent.mParameters.deleted,
				aRenamedVariants = oEvent.mParameters.renamed,
				sNewDefaultVariantKey = oEvent.mParameters.def;

			if (aDeletedVariants.length > 0) {
				this.deleteVariants(aDeletedVariants, function (bDeleted) {
					// delete success if bDeleted is true
				});
			}

			if (aRenamedVariants.length > 0) {
				this.renameVariants(aRenamedVariants, function (bRenamed) {

				});
			}

			this.setNewDefault(sNewDefaultVariantKey, function (bChanged) {

			});

		},

		deleteVariants: function (aVariantKeys, fnCallback) {
			var oPersonalizationVariantSet = {};
			this._oPersonalizationContainer.fail(function () {
				//handle failure case
			});

			this._oPersonalizationContainer.done(function (oPersonalizationContainer) {
				if (!(oPersonalizationContainer.containsVariantSet(sPersonalizationContainerName))) {
					oPersonalizationContainer.addVariantSet(sPersonalizationContainerName);
				}

				oPersonalizationVariantSet = oPersonalizationContainer.getVariantSet(sPersonalizationContainerName);
				for (var iCount = 0; iCount < aVariantKeys.length; iCount++) {
					if (aVariantKeys[iCount]) {
						oPersonalizationVariantSet.delVariant(aVariantKeys[iCount]);
					}
				}

				oPersonalizationContainer.save().fail(function () {
					//handle failure case
					fnCallback(false);
				}).done(function () {
					fnCallback(true);
				}.bind(this));

			}.bind(this));
		},

		onSelectVariant: function (oEvent) {
			this.getView().byId("variantManagement").currentVariantSetModified(true);
			var sSelectedVariantKey = oEvent.mParameters.key;

			if (sSelectedVariantKey) {
				this.getVariantFromKey(sSelectedVariantKey, function (oSelectedVariant) {
					if (oSelectedVariant == undefined) {
						this.applyFilterData(oInitControllState);
					} else {
						this.applyFilterData(JSON.parse(oSelectedVariant.getItemValue("Filter")));
					}
				}.bind(this));
			}
		},
		applyFilterData: function (oFilterData) {
			if (oFilterData.filters[0].key === "supplierFrom" && oFilterData.filters[0].value !== "") {
				var __self = this;
				oFilterData.filters.map(function (filter) {
					var oControll = __self.getView().byId(filter.key);

					switch (filter.key) {
					case 'supplierFrom':
						oControll.setSelectedKey(filter.value);
						if (!!filter.value.length) {
							oControll.fireChange();
							oControll.fireSelectionChange();
						}
						break;
					case 'pickupDate':
					case 'pickupDateTo':
						oControll.setValue(filter.value);
						oControll.fireChange();
						break;
					default:
						oControll.setValue(filter.value);
						break;
					}
				});
			}
		},

		getVariantFromKey: function (sVariantKey, fnCallback) {
			this._oPersonalizationContainer.fail(function () {
				// call back function in case of fail
				if (fnCallback) {
					fnCallback('');
				}
			});

			this._oPersonalizationContainer.done(function (oPersonalizationContainer) {
				var oPersonalizationVariantSet = {};

				// check if the current variant set exists, If not, add the new variant set to the container
				if (!(oPersonalizationContainer.containsVariantSet(sPersonalizationContainerName))) {
					oPersonalizationContainer.addVariantSet(sPersonalizationContainerName);
				}

				// get the variant set
				oPersonalizationVariantSet = oPersonalizationContainer.getVariantSet(sPersonalizationContainerName);
				fnCallback(oPersonalizationVariantSet.getVariant(sVariantKey));
			});
		},
		onSelectRow: function (oEvent) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				iPath = parseInt(oEvent.getSource().getSelectedContextPaths()[0].split("/")[2]),
				aData = appModel.getProperty("/aPlantDescSet"),
				aGsData = this.getView().getModel("appModel").getProperty("/aGoodsSupplier"),
				oFilteredData = jQuery.grep(aGsData, function (oObj) {
					return oObj.Plant == aData[iPath].Plant;
				});
			jQuery.grep(aData, function (oObj) {
				oObj.bSelected = false;
				oObj.GSvalue = "";
			});
			aData[iPath].bSelected = true;
			appModel.setProperty("/iPath", iPath);
			appModel.setProperty("/oGoodsSupplier", oFilteredData);
			if (oFilteredData.length == 1) {
				aData[iPath].GSvalue = oFilteredData[0].SuppVendor + " - " + oFilteredData[0].Name + " - " + oFilteredData[0].HouseNum + " - " +
					oFilteredData[0].City;
				// oView.byId("idGoodsSupplier").setSelectedKey(oFilteredData[0].SuppVendor)
				oView.byId("idCreChng").setVisible(true);
			} else if (oFilteredData.length == 0) {
				oView.byId("idCreChng").setVisible(true);
				aData[iPath].bSelected = false;
			} else {
				oView.byId("idCreChng").setVisible(false);
			}
			appModel.refresh()
		},
		onCreateChange: function (oEvent) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				selpaths = this.getView().byId("idTransTable").getSelectedContextPaths(),
				sPath = this.getView().byId("idTransTable").getSelectedContextPaths()[0];

			// #MS
			var oSelectedItem = appModel.getProperty(sPath),
				oRouter = sap.ui.core.UIComponent.getRouterFor(this),
				oView = this.getView(),
				appModel = oView.getModel("appModel");
			// appModel.setProperty("/supplier", gSupplier);
			appModel.setProperty("/fromdate", gPickupDateF.replaceAll("-", ""));
			appModel.setProperty("/todate", gPickupDateT.replaceAll("-", ""));
			appModel.setProperty("/plant", oSelectedItem.Plant);
			appModel.setProperty("/oSelectedItem", oSelectedItem);
			appModel.setProperty("/SupplierValue", this.getView().byId("supplierFrom").getProperty("value"));
			appModel.setProperty("/fromMainCtrl", true);
			appModel.setProperty("/fromPackCtrl", false);
			appModel.setProperty("/bNextPressEnable", false);
			if (oSelectedItem.Country == "X") {
				appModel.setProperty("/bTurkishPlant", true);
			} else {
				appModel.setProperty("/bTurkishPlant", false);
			}
			oRouter.navTo("create");
			// oRouter.navTo("create",{suppl : btoa(gSupplier), fromdate: gPickupDateF, todate: gPickupDateT, plant: _self.plant});
		},
		displayErrorMessage: function (msg) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			if (!msg === false) {
				MessageBox.error(
					msg, {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
			} else {
				MessageBox.error(
					_self.bundle.getText("EnterMandatoryParameters"), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
			}
		},
		handleGSLoadItems: function (oEvent, sPlant) {
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				aGsData = this.getView().getModel("appModel").getProperty("/aGoodsSupplier"),
				oFilteredData = jQuery.grep(aGsData, function (oObj) {
					return oObj.Plant == sPlant;
				}),
				aFilter = [new Filter([
					new Filter("Plant", FilterOperator.EQ, sPlant)
				])];
			oEvent.getSource().getBinding("items").filter(aFilter);

			if (oFilteredData.length == 1)
				oEvent.getSource().setSelectedKey(oFilteredData[0].SuppVendor);
			// appModel.setProperty("/oGoodsSupplier", []);
			// appModel.setProperty("/oGoodsSupplier", oFilteredData);
		},
		onGoodsSupplierChange: function (oEvent) {
			// var oTable = this.getView().byId("idTransTable");
			var oView = this.getView(),
				appModel = oView.getModel("appModel"),
				iPath = appModel.getProperty("/iPath"),
				aData = appModel.getProperty("/aPlantDescSet");
			aData[iPath].GSvalue = oEvent.getParameter("value");
			this.getView().byId("idCreChng").setVisible(true);
		},
		validateDateTo: function (oEvent) {
			if (oEvent.getSource().isValidValue()) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState("Error");
				this.getMessageBox("addCal", "E");
				oEvent.getSource().setValue("");
			}
		},
		getMessageBox: function (bundleText, statusFlag) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			if (statusFlag == "E") {
				MessageBox.error(
					this.bundle.getText(bundleText), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
			} else if (statusFlag == "S") {
				MessageBox.success(
					this.bundle.getText(bundleText), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
			}
		},
		openBusyDialog: function () {
			if (!this.busyDialog) {
				this.busyDialog = new BusyDialog();
			}
			this.busyDialog.open();
			this.busyDialog.setBusyIndicatorDelay(10000);
		},
		closeBusyDiaog: function () {
			this.busyDialog.close();
		},
		btnpress: function () {
			var languageFile = this.getView().getModel("i18n").getResourceBundle();
			var a = window.location.href;
			var b = a.split("#");
			var c = b[0];
			var d = c.concat("#SU_SHIPPING_NOTIF-display");
			// var para = trList.notification[0];
			//////////////////////////////////////////////////////////////
			// window.open(d + '?Plant=' + para.Plant + '&Mat=&Vendor=' + para.Vendor+"&arrDte="+para.DateOfArrival+'&type=pack', "");
			window.open(d + '?Plant=1409&Mat=&Vendor=&arrDte=&type=pack&navFrom=true', "");
			// this.oRouter.navTo("main");
		}
	});
});